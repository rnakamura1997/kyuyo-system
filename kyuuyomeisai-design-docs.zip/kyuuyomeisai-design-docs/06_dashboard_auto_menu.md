# ダッシュボード自動生成方式

**文書バージョン**: v1.0  
**作成日**: 2026-02-09

---

## 1. 概要

### 1.1 目的
給与明細管理システムのダッシュボードメニューを、システムのルーティング定義から**自動的に生成**し、以下を実現する：

1. **手動介入不要**: 新機能追加時にメニュー定義を手動更新する必要がない
2. **権限別表示**: ログインユーザーの権限に応じて自動フィルタリング
3. **拡張性**: 将来の機能追加に自動追従
4. **保守性**: メニュー構造とルーティングの一元管理

---

## 2. 設計方針

### 2.1 基本アイデア

**ルーティング定義 = メニュー構造**

Reactのルーティング定義に**メタ情報**を付加し、それを元にメニューを動的生成する。

### 2.2 メタ情報の構造

```typescript
interface RouteMetadata {
  title: string;              // メニュー表示名
  icon?: string;             // Material-UIアイコン名
  inMenu: boolean;           // メニューに表示するか
  requiredRoles: string[];   // 必要な権限（複数可）
  order?: number;            // 表示順序
  group?: string;            // メニューグループ
  badge?: () => number;      // バッジ表示（未読数など）
}
```

---

## 3. 実装方法

### 3.1 ルーティング定義例

```typescript
// src/routes/routes.tsx

import { RouteObject } from 'react-router-dom';
import DashboardIcon from '@mui/icons-material/Dashboard';
import PeopleIcon from '@mui/icons-material/People';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import DescriptionIcon from '@mui/icons-material/Description';
import AssessmentIcon from '@mui/icons-material/Assessment';
import SettingsIcon from '@mui/icons-material/Settings';

export interface ExtendedRouteObject extends RouteObject {
  meta?: RouteMetadata;
  children?: ExtendedRouteObject[];
}

const routes: ExtendedRouteObject[] = [
  {
    path: '/',
    element: <DashboardLayout />,
    children: [
      {
        path: 'dashboard',
        element: <DashboardPage />,
        meta: {
          title: 'ダッシュボード',
          icon: 'Dashboard',
          inMenu: true,
          requiredRoles: ['super_admin', 'admin', 'accountant', 'employee'],
          order: 1,
          group: 'main'
        }
      },
      {
        path: 'companies',
        element: <CompaniesPage />,
        meta: {
          title: '会社管理',
          icon: 'Business',
          inMenu: true,
          requiredRoles: ['super_admin'],
          order: 10,
          group: 'master'
        }
      },
      {
        path: 'employees',
        element: <EmployeesPage />,
        meta: {
          title: '従業員管理',
          icon: 'People',
          inMenu: true,
          requiredRoles: ['super_admin', 'admin'],
          order: 11,
          group: 'master'
        },
        children: [
          {
            path: 'new',
            element: <EmployeeFormPage />,
            meta: {
              title: '従業員登録',
              inMenu: false,
              requiredRoles: ['super_admin', 'admin']
            }
          }
        ]
      },
      {
        path: 'attendance',
        element: <AttendancePage />,
        meta: {
          title: '勤怠データ',
          icon: 'AccessTime',
          inMenu: true,
          requiredRoles: ['super_admin', 'admin', 'accountant'],
          order: 20,
          group: 'payroll'
        }
      },
      {
        path: 'payroll',
        element: <PayrollPage />,
        meta: {
          title: '給与計算',
          icon: 'AttachMoney',
          inMenu: true,
          requiredRoles: ['super_admin', 'admin', 'accountant'],
          order: 21,
          group: 'payroll'
        }
      },
      {
        path: 'payroll-records',
        element: <PayrollRecordsPage />,
        meta: {
          title: '給与明細一覧',
          icon: 'Description',
          inMenu: true,
          requiredRoles: ['super_admin', 'admin', 'accountant', 'employee'],
          order: 22,
          group: 'payroll'
        }
      },
      {
        path: 'year-end-adjustment',
        element: <YearEndAdjustmentPage />,
        meta: {
          title: '年末調整',
          icon: 'Assignment',
          inMenu: true,
          requiredRoles: ['super_admin', 'admin', 'accountant', 'employee'],
          order: 30,
          group: 'tax'
        }
      },
      {
        path: 'reports',
        element: <ReportsPage />,
        meta: {
          title: '帳票出力',
          icon: 'Assessment',
          inMenu: true,
          requiredRoles: ['super_admin', 'admin', 'accountant'],
          order: 40,
          group: 'reports'
        }
      },
      {
        path: 'settings',
        element: <SettingsPage />,
        meta: {
          title: 'システム設定',
          icon: 'Settings',
          inMenu: true,
          requiredRoles: ['super_admin', 'admin'],
          order: 50,
          group: 'settings'
        },
        children: [
          {
            path: 'allowances',
            element: <AllowanceTypesPage />,
            meta: {
              title: '手当設定',
              inMenu: true,
              requiredRoles: ['super_admin', 'admin'],
              order: 51
            }
          },
          {
            path: 'rates',
            element: <RatesPage />,
            meta: {
              title: '料率管理',
              inMenu: true,
              requiredRoles: ['super_admin'],
              order: 52
            }
          }
        ]
      }
    ]
  }
];

export default routes;
```

---

### 3.2 メニュー生成ユーティリティ

```typescript
// src/utils/menuGenerator.ts

import { ExtendedRouteObject } from '../routes/routes';

interface MenuItem {
  path: string;
  title: string;
  icon?: string;
  order: number;
  group: string;
  badge?: number;
  children?: MenuItem[];
}

interface MenuGroup {
  name: string;
  items: MenuItem[];
}

/**
 * ルーティング定義からメニュー項目を抽出
 */
export function generateMenuItems(
  routes: ExtendedRouteObject[],
  userRoles: string[],
  basePath: string = ''
): MenuItem[] {
  const items: MenuItem[] = [];

  routes.forEach(route => {
    if (!route.meta || !route.meta.inMenu) return;

    // 権限チェック
    const hasPermission = route.meta.requiredRoles.some(role =>
      userRoles.includes(role)
    );
    if (!hasPermission) return;

    // メニュー項目作成
    const item: MenuItem = {
      path: basePath + '/' + route.path,
      title: route.meta.title,
      icon: route.meta.icon,
      order: route.meta.order || 999,
      group: route.meta.group || 'other',
      badge: route.meta.badge ? route.meta.badge() : undefined,
      children: route.children
        ? generateMenuItems(route.children, userRoles, basePath + '/' + route.path)
        : undefined
    };

    items.push(item);
  });

  // 表示順でソート
  return items.sort((a, b) => a.order - b.order);
}

/**
 * メニュー項目をグループ化
 */
export function groupMenuItems(items: MenuItem[]): MenuGroup[] {
  const groups = new Map<string, MenuItem[]>();

  items.forEach(item => {
    const groupName = item.group;
    if (!groups.has(groupName)) {
      groups.set(groupName, []);
    }
    groups.get(groupName)!.push(item);
  });

  const groupOrder = {
    main: 0,
    master: 1,
    payroll: 2,
    tax: 3,
    reports: 4,
    settings: 5,
    other: 99
  };

  return Array.from(groups.entries())
    .map(([name, items]) => ({ name, items }))
    .sort((a, b) => (groupOrder[a.name] || 99) - (groupOrder[b.name] || 99));
}
```

---

### 3.3 サイドバーコンポーネント

```typescript
// src/components/layout/Sidebar.tsx

import React from 'react';
import {
  Drawer,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  ListItemButton,
  Divider,
  Typography,
  Badge
} from '@mui/material';
import { useNavigate, useLocation } from 'react-router-dom';
import * as Icons from '@mui/icons-material';
import { useAuth } from '../../hooks/useAuth';
import routes from '../../routes/routes';
import { generateMenuItems, groupMenuItems } from '../../utils/menuGenerator';

const drawerWidth = 260;

export const Sidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();

  // ユーザーの権限を取得
  const userRoles = user?.roles || [];

  // メニュー項目を自動生成
  const menuItems = generateMenuItems(routes, userRoles);
  const groupedMenus = groupMenuItems(menuItems);

  // グループ名の日本語変換
  const groupLabels = {
    main: 'メイン',
    master: 'マスタ管理',
    payroll: '給与管理',
    tax: '税務',
    reports: '帳票・レポート',
    settings: '設定',
    other: 'その他'
  };

  // アイコンコンポーネント取得
  const getIcon = (iconName?: string) => {
    if (!iconName) return null;
    const IconComponent = Icons[iconName];
    return IconComponent ? <IconComponent /> : null;
  };

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box'
        }
      }}
    >
      {/* ロゴ */}
      <div style={{ padding: '16px', textAlign: 'center' }}>
        <Typography variant="h6">給与明細管理</Typography>
      </div>
      <Divider />

      {/* メニュー */}
      {groupedMenus.map((group, groupIndex) => (
        <React.Fragment key={group.name}>
          {groupIndex > 0 && <Divider />}
          <Typography
            variant="caption"
            sx={{ px: 2, pt: 2, pb: 1, color: 'text.secondary' }}
          >
            {groupLabels[group.name] || group.name}
          </Typography>
          <List>
            {group.items.map(item => (
              <ListItem key={item.path} disablePadding>
                <ListItemButton
                  selected={location.pathname === item.path}
                  onClick={() => navigate(item.path)}
                >
                  {item.icon && (
                    <ListItemIcon>{getIcon(item.icon)}</ListItemIcon>
                  )}
                  <ListItemText primary={item.title} />
                  {item.badge && (
                    <Badge badgeContent={item.badge} color="error" />
                  )}
                </ListItemButton>
              </ListItem>
            ))}
          </List>
        </React.Fragment>
      ))}
    </Drawer>
  );
};
```

---

## 4. 権限制御

### 4.1 権限チェックフック

```typescript
// src/hooks/usePermission.ts

import { useAuth } from './useAuth';

export function usePermission() {
  const { user } = useAuth();

  const hasRole = (roles: string | string[]): boolean => {
    if (!user) return false;

    const roleArray = Array.isArray(roles) ? roles : [roles];
    return roleArray.some(role => user.roles.includes(role));
  };

  const hasAnyRole = (roles: string[]): boolean => {
    return hasRole(roles);
  };

  const hasAllRoles = (roles: string[]): boolean => {
    if (!user) return false;
    return roles.every(role => user.roles.includes(role));
  };

  return { hasRole, hasAnyRole, hasAllRoles };
}
```

### 4.2 ルート保護HOC

```typescript
// src/components/auth/ProtectedRoute.tsx

import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { usePermission } from '../../hooks/usePermission';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: string[];
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({
  children,
  requiredRoles = []
}) => {
  const { isAuthenticated } = useAuth();
  const { hasAnyRole } = usePermission();

  if (!isAuthenticated) {
    return <Navigate to="/login" />;
  }

  if (requiredRoles.length > 0 && !hasAnyRole(requiredRoles)) {
    return <Navigate to="/unauthorized" />;
  }

  return <>{children}</>;
};
```

---

## 5. 動的バッジ表示

### 5.1 未読通知カウント例

```typescript
// src/hooks/useNotificationBadge.ts

import { useState, useEffect } from 'react';
import { apiClient } from '../services/api';

export function useNotificationBadge(): number {
  const [count, setCount] = useState(0);

  useEffect(() => {
    const fetchCount = async () => {
      try {
        const response = await apiClient.get('/notifications/unread-count');
        setCount(response.data.count);
      } catch (error) {
        console.error('Failed to fetch notification count', error);
      }
    };

    fetchCount();
    const interval = setInterval(fetchCount, 60000); // 1分ごと

    return () => clearInterval(interval);
  }, []);

  return count;
}
```

### 5.2 ルーティング定義での使用

```typescript
{
  path: 'notifications',
  element: <NotificationsPage />,
  meta: {
    title: '通知',
    icon: 'Notifications',
    inMenu: true,
    requiredRoles: ['super_admin', 'admin', 'accountant', 'employee'],
    order: 2,
    group: 'main',
    badge: () => useNotificationBadge()  // 動的バッジ
  }
}
```

---

## 6. 新機能追加の手順

### 従来の方法（手動）
1. 新しいページコンポーネントを作成
2. ルーティング定義に追加
3. **サイドバーメニューに手動で追加** ← 手間・ミスの元

### 自動メニュー生成方式
1. 新しいページコンポーネントを作成
2. ルーティング定義に**メタ情報付きで追加**
3. **自動的にメニューに反映** ← 作業完了！

**例**: 新機能「勤怠承認」を追加

```typescript
{
  path: 'attendance-approval',
  element: <AttendanceApprovalPage />,
  meta: {
    title: '勤怠承認',
    icon: 'HowToReg',
    inMenu: true,
    requiredRoles: ['super_admin', 'admin'],
    order: 23,
    group: 'payroll'
  }
}
```

↓ **これだけでメニューに自動追加！**

---

## 7. メリット

### 7.1 開発効率
- メニュー定義の二重管理が不要
- 新機能追加時の作業が1箇所で完結

### 7.2 保守性
- ルーティングとメニューの不整合を防止
- 権限制御が一元管理

### 7.3 拡張性
- 新しいメニューグループの追加が容易
- バッジ・アイコン等のカスタマイズが柔軟

### 7.4 一貫性
- 全画面で統一されたメニュー構造
- 権限による表示制御が自動適用

---

## 8. 注意点

### 8.1 パフォーマンス
- メニュー生成はレンダリング時に毎回実行されるため、useMemoで最適化

```typescript
const menuItems = useMemo(
  () => generateMenuItems(routes, userRoles),
  [userRoles]
);
```

### 8.2 動的ルート
- 動的パラメータを含むルート（例: `/employees/:id`）は`inMenu: false`に

### 8.3 国際化（i18n）
- メタ情報の`title`を翻訳キーにして、i18nライブラリで変換

---

**文書終了**
