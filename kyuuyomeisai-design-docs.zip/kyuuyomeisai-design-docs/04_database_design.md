# データベース詳細設計

**文書バージョン**: v1.0  
**作成日**: 2026-02-09

---

## 1. データベース設計概要

### 1.1 基本方針
- **RDBMS**: PostgreSQL 15+
- **文字コード**: UTF-8
- **タイムゾーン**: Asia/Tokyo
- **命名規則**: スネークケース
- **マルチテナント**: Row-level分離（company_id）
- **セキュリティ**: Row Level Security (RLS) 適用

---

## 2. テーブル一覧

| # | テーブル名 | 説明 | company_id |
|---|-----------|------|-----------|
| 1 | roles | ロール定義 | なし |
| 2 | system_settings | システム設定 | なし |
| 3 | income_tax_tables | 所得税額表 | なし |
| 4 | commute_tax_limits | 通勤手当非課税限度額 | なし |
| 5 | insurance_constants | 社会保険定数 | なし |
| 6 | companies | 会社マスタ | あり |
| 7 | users | ユーザーアカウント | あり |
| 8 | user_roles | ユーザーロール紐付け | あり |
| 9 | employees | 従業員マスタ | あり |
| 10 | allowance_types | 手当種別マスタ | あり |
| 11 | employee_allowances | 従業員手当設定 | あり |
| 12 | commute_details | 通勤情報 | あり |
| 13 | insurance_rates | 社会保険料率 | あり |
| 14 | attendance_records | 勤怠データ | あり |
| 15 | payroll_periods | 給与期間 | あり |
| 16 | payroll_record_groups | 給与明細グループ | あり |
| 17 | payroll_records | 給与明細 | あり |
| 18 | payroll_record_items | 給与明細項目 | あり |
| 19 | payroll_snapshots | 給与スナップショット | あり |
| 20 | payroll_histories | 給与履歴 | あり |
| 21 | bonus_events | 賞与イベント | あり |
| 22 | bonus_records | 賞与明細 | あり |
| 23 | year_end_adjustments | 年末調整 | あり |
| 24 | year_end_adjustment_histories | 年末調整履歴 | あり |
| 25 | deduction_certificates | 控除証明書 | あり |
| 26 | tax_withholding_slips | 源泉徴収票 | あり |
| 27 | payroll_notification_tokens | 明細通知トークン | あり |
| 28 | accounting_mappings | 会計科目マッピング | あり |
| 29 | bank_transfer_exports | 銀行振込データ | あり |
| 30 | audit_logs | 監査ログ | あり |

---

## 3. テーブル定義（DDL）

### 3.1 グローバルテーブル（company_id なし）

#### roles（ロール定義）

```sql
CREATE TABLE roles (
    id              BIGSERIAL PRIMARY KEY,
    code            TEXT NOT NULL UNIQUE,
    name            TEXT NOT NULL,
    description     TEXT,
    permissions     JSONB,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 初期データ
INSERT INTO roles (code, name, description) VALUES
('super_admin', 'スーパー管理者', '全社横断管理'),
('admin', '管理者', '会社内全権限'),
('accountant', '経理担当', '給与計算・帳票出力'),
('employee', '一般従業員', '自分の明細閲覧のみ');
```

#### system_settings（システム設定）

```sql
CREATE TABLE system_settings (
    id              BIGSERIAL PRIMARY KEY,
    setting_key     TEXT NOT NULL UNIQUE,
    setting_value   JSONB,
    description     TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### income_tax_tables（所得税額表）

```sql
CREATE TABLE income_tax_tables (
    id                  BIGSERIAL PRIMARY KEY,
    table_type          TEXT NOT NULL CHECK (table_type IN ('monthly_kou', 'daily_kou', 'otsu', 'hei')),
    valid_from          DATE NOT NULL,
    valid_to            DATE,
    income_from         INTEGER NOT NULL,
    income_to           INTEGER,
    dependents_count    INTEGER NOT NULL DEFAULT 0,
    tax_amount          INTEGER NOT NULL,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_income_tax_tables_lookup 
    ON income_tax_tables(table_type, valid_from, valid_to, income_from, dependents_count);
```

#### commute_tax_limits（通勤手当非課税限度額）

```sql
CREATE TABLE commute_tax_limits (
    id              BIGSERIAL PRIMARY KEY,
    valid_from      DATE NOT NULL,
    valid_to        DATE,
    commute_type    TEXT NOT NULL CHECK (commute_type IN ('public_transport', 'car', 'bicycle', 'mixed')),
    distance_from   NUMERIC(5,1),
    distance_to     NUMERIC(5,1),
    limit_amount    INTEGER NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_commute_tax_limits_lookup 
    ON commute_tax_limits(valid_from, valid_to, commute_type);
```

#### insurance_constants（社会保険定数）

```sql
CREATE TABLE insurance_constants (
    id                      BIGSERIAL PRIMARY KEY,
    constant_type           TEXT NOT NULL CHECK (constant_type IN ('bonus_health_limit', 'bonus_pension_limit')),
    valid_from              DATE NOT NULL,
    valid_to                DATE,
    limit_amount            INTEGER NOT NULL,
    description             TEXT,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 初期データ例
INSERT INTO insurance_constants (constant_type, valid_from, limit_amount, description) VALUES
('bonus_health_limit', '2024-04-01', 5730000, '健康保険賞与上限（年度573万円）'),
('bonus_pension_limit', '2024-04-01', 1500000, '厚生年金賞与上限（月150万円）');
```

---

### 3.2 会社・ユーザー関連

#### companies（会社マスタ）

```sql
CREATE TABLE companies (
    id                              BIGSERIAL PRIMARY KEY,
    company_id                      BIGINT NOT NULL,
    name                            TEXT NOT NULL,
    name_kana                       TEXT,
    address                         TEXT,
    phone                           TEXT,
    representative_name             TEXT,
    legal_number                    TEXT,
    logo_path                       TEXT,
    
    -- 給与設定
    closing_day                     INTEGER NOT NULL CHECK (closing_day BETWEEN 1 AND 31),
    payment_day                     INTEGER NOT NULL CHECK (payment_day BETWEEN 1 AND 31),
    payment_month_offset            INTEGER DEFAULT 1,
    
    -- 健康保険
    health_insurance_type           TEXT CHECK (health_insurance_type IN ('kyokai', 'kumiai')),
    health_insurance_prefecture     TEXT,
    health_insurance_union_name     TEXT,
    business_office_symbol          TEXT,
    care_insurance_applicable       BOOLEAN DEFAULT true,
    
    -- 厚生年金
    pension_office_number           TEXT,
    
    -- 雇用保険
    employment_office_number        TEXT,
    employment_business_type        TEXT,
    
    -- その他
    settings                        JSONB,
    is_deleted                      BOOLEAN DEFAULT false,
    created_at                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_companies_company_id UNIQUE (company_id)
);

CREATE INDEX idx_companies_company_id ON companies(company_id) WHERE is_deleted = false;
```

#### users（ユーザーアカウント）

```sql
CREATE TABLE users (
    id                  BIGSERIAL PRIMARY KEY,
    company_id          BIGINT NOT NULL REFERENCES companies(company_id) ON DELETE RESTRICT,
    username            TEXT NOT NULL,
    email               CITEXT NOT NULL,
    password_hash       TEXT NOT NULL,
    full_name           TEXT NOT NULL,
    is_super_admin      BOOLEAN DEFAULT false,
    is_active           BOOLEAN DEFAULT true,
    last_login_at       TIMESTAMP,
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_users_username UNIQUE (username),
    CONSTRAINT uk_users_email UNIQUE (email)
);

CREATE INDEX idx_users_company_id ON users(company_id);
CREATE INDEX idx_users_email ON users(email);
```

#### user_roles（ユーザーロール紐付け）

```sql
CREATE TABLE user_roles (
    id              BIGSERIAL PRIMARY KEY,
    company_id      BIGINT NOT NULL,
    user_id         BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id         BIGINT NOT NULL REFERENCES roles(id) ON DELETE RESTRICT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_user_roles UNIQUE (user_id, role_id)
);

CREATE INDEX idx_user_roles_user_id ON user_roles(user_id);
```

---

### 3.3 従業員関連

#### employees（従業員マスタ）

```sql
CREATE TABLE employees (
    id                              BIGSERIAL PRIMARY KEY,
    company_id                      BIGINT NOT NULL,
    employee_code                   TEXT NOT NULL,
    
    -- 基本情報
    first_name                      TEXT NOT NULL,
    last_name                       TEXT NOT NULL,
    first_name_kana                 TEXT,
    last_name_kana                  TEXT,
    email                           CITEXT,
    birth_date                      DATE,
    gender                          TEXT CHECK (gender IN ('male', 'female', 'other')),
    address                         TEXT,
    phone                           TEXT,
    
    -- 雇用情報
    hire_date                       DATE NOT NULL,
    termination_date                DATE,
    employment_type                 TEXT NOT NULL,
    department                      TEXT,
    position                        TEXT,
    
    -- 給与設定
    salary_type                     TEXT NOT NULL CHECK (salary_type IN ('daily', 'hourly', 'monthly', 'commission')),
    salary_settings                 JSONB NOT NULL,
    
    -- 税金・社会保険
    tax_category                    TEXT NOT NULL CHECK (tax_category IN ('kou', 'otsu', 'hei')),
    dependents_count                INTEGER DEFAULT 0,
    social_insurance_enrolled       BOOLEAN DEFAULT false,
    pension_insurance_enrolled      BOOLEAN DEFAULT false,
    employment_insurance_enrolled   BOOLEAN DEFAULT false,
    resident_tax_type               TEXT CHECK (resident_tax_type IN ('special', 'ordinary')),
    resident_tax_monthly_amount     INTEGER,
    
    -- 銀行口座
    bank_name                       TEXT,
    branch_name                     TEXT,
    account_type                    TEXT CHECK (account_type IN ('savings', 'checking')),
    account_number                  TEXT,
    account_holder                  TEXT,
    
    -- その他
    notes                           TEXT,
    is_deleted                      BOOLEAN DEFAULT false,
    created_at                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_employees_company_code UNIQUE (company_id, employee_code)
);

CREATE INDEX idx_employees_company_id ON employees(company_id) WHERE is_deleted = false;
CREATE INDEX idx_employees_email ON employees(email);
CREATE INDEX idx_employees_hire_date ON employees(hire_date);

-- RLS設定
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees FORCE ROW LEVEL SECURITY;
```

#### allowance_types（手当種別マスタ）

```sql
CREATE TABLE allowance_types (
    id                          BIGSERIAL PRIMARY KEY,
    company_id                  BIGINT NOT NULL,
    code                        TEXT NOT NULL,
    name                        TEXT NOT NULL,
    is_taxable                  BOOLEAN DEFAULT true,
    is_social_insurance_target  BOOLEAN DEFAULT true,
    is_employment_insurance_target BOOLEAN DEFAULT true,
    is_overtime_base            BOOLEAN DEFAULT false,
    is_active                   BOOLEAN DEFAULT true,
    display_order               INTEGER,
    created_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_allowance_types_company_code UNIQUE (company_id, code)
);

CREATE INDEX idx_allowance_types_company_id ON allowance_types(company_id);
```

#### employee_allowances（従業員手当設定）

```sql
CREATE TABLE employee_allowances (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    employee_id             BIGINT NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    allowance_type_id       BIGINT NOT NULL REFERENCES allowance_types(id) ON DELETE RESTRICT,
    amount                  INTEGER NOT NULL,
    effective_from          DATE NOT NULL,
    effective_to            DATE,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_employee_allowances_employee_id ON employee_allowances(employee_id);
CREATE INDEX idx_employee_allowances_effective ON employee_allowances(effective_from, effective_to);
```

#### commute_details（通勤情報）

```sql
CREATE TABLE commute_details (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    employee_id             BIGINT NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    commute_method          TEXT NOT NULL CHECK (commute_method IN ('public_transport', 'car', 'bicycle', 'mixed')),
    distance                NUMERIC(5,1),
    route                   TEXT,
    monthly_cost            INTEGER,
    non_taxable_limit       INTEGER,
    effective_from          DATE NOT NULL,
    effective_to            DATE,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_commute_details_employee_id ON commute_details(employee_id);
```

---

### 3.4 料率テーブル

#### insurance_rates（社会保険料率）

```sql
CREATE TABLE insurance_rates (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT,
    insurance_type          TEXT NOT NULL CHECK (insurance_type IN ('health', 'pension', 'employment')),
    valid_from              DATE NOT NULL,
    valid_to                DATE,
    prefecture              TEXT,
    business_type           TEXT,
    employee_rate           NUMERIC(6,5) NOT NULL,
    employer_rate           NUMERIC(6,5) NOT NULL,
    care_insurance_rate     NUMERIC(6,5),
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_insurance_rates_lookup 
    ON insurance_rates(insurance_type, valid_from, valid_to, prefecture);
```

---

### 3.5 勤怠・給与期間

#### attendance_records（勤怠データ）

```sql
CREATE TABLE attendance_records (
    id                                  BIGSERIAL PRIMARY KEY,
    company_id                          BIGINT NOT NULL,
    employee_id                         BIGINT NOT NULL REFERENCES employees(id) ON DELETE RESTRICT,
    year_month                          INTEGER NOT NULL,
    
    -- 勤務日数
    statutory_work_days                 INTEGER,
    work_days                           INTEGER,
    absence_days                        INTEGER DEFAULT 0,
    late_count                          INTEGER DEFAULT 0,
    early_leave_count                   INTEGER DEFAULT 0,
    paid_leave_days                     NUMERIC(3,1) DEFAULT 0,
    substitute_holiday_days             NUMERIC(3,1) DEFAULT 0,
    
    -- 労働時間（分単位）
    total_work_minutes                  INTEGER,
    regular_minutes                     INTEGER,
    overtime_within_statutory_minutes   INTEGER DEFAULT 0,
    overtime_statutory_minutes          INTEGER DEFAULT 0,
    night_minutes                       INTEGER DEFAULT 0,
    statutory_holiday_minutes           INTEGER DEFAULT 0,
    non_statutory_holiday_minutes       INTEGER DEFAULT 0,
    night_overtime_minutes              INTEGER DEFAULT 0,
    night_holiday_minutes               INTEGER DEFAULT 0,
    night_overtime_holiday_minutes      INTEGER DEFAULT 0,
    
    -- その他
    notes                               TEXT,
    created_at                          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at                          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_attendance_records UNIQUE (company_id, employee_id, year_month)
);

CREATE INDEX idx_attendance_records_employee_month 
    ON attendance_records(employee_id, year_month);
CREATE INDEX idx_attendance_records_company_month 
    ON attendance_records(company_id, year_month);

-- RLS設定
ALTER TABLE attendance_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_records FORCE ROW LEVEL SECURITY;
```

#### payroll_periods（給与期間）

```sql
CREATE TABLE payroll_periods (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    period_type             TEXT NOT NULL CHECK (period_type IN ('monthly', 'weekly', 'daily')),
    year_month              INTEGER NOT NULL,
    start_date              DATE NOT NULL,
    end_date                DATE NOT NULL,
    payment_date            DATE NOT NULL,
    closing_date            DATE NOT NULL,
    weekly_closing_day      INTEGER CHECK (weekly_closing_day BETWEEN 0 AND 6),
    status                  TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'confirmed', 'paid')),
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payroll_periods_company_id ON payroll_periods(company_id);
CREATE INDEX idx_payroll_periods_year_month ON payroll_periods(company_id, year_month);

-- RLS設定
ALTER TABLE payroll_periods ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_periods FORCE ROW LEVEL SECURITY;
```

---

### 3.6 給与明細関連

#### payroll_record_groups（給与明細グループ）

```sql
CREATE TABLE payroll_record_groups (
    id                          BIGSERIAL PRIMARY KEY,
    company_id                  BIGINT NOT NULL,
    employee_id                 BIGINT NOT NULL REFERENCES employees(id) ON DELETE RESTRICT,
    payroll_period_id           BIGINT NOT NULL REFERENCES payroll_periods(id) ON DELETE RESTRICT,
    current_payroll_record_id   BIGINT,
    created_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_payroll_record_groups UNIQUE (company_id, employee_id, payroll_period_id)
);

CREATE INDEX idx_payroll_groups_employee ON payroll_record_groups(employee_id);
CREATE INDEX idx_payroll_groups_period ON payroll_record_groups(payroll_period_id);

-- RLS設定
ALTER TABLE payroll_record_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_record_groups FORCE ROW LEVEL SECURITY;
```

#### payroll_records（給与明細）

```sql
CREATE TABLE payroll_records (
    id                          BIGSERIAL PRIMARY KEY,
    company_id                  BIGINT NOT NULL,
    payroll_record_group_id     BIGINT NOT NULL REFERENCES payroll_record_groups(id) ON DELETE RESTRICT,
    employee_id                 BIGINT NOT NULL REFERENCES employees(id) ON DELETE RESTRICT,
    payroll_period_id           BIGINT NOT NULL REFERENCES payroll_periods(id) ON DELETE RESTRICT,
    
    version                     INTEGER NOT NULL DEFAULT 1,
    status                      TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'confirmed', 'cancelled')),
    
    payment_date                DATE NOT NULL,
    
    -- 金額（円単位）
    total_earnings              INTEGER NOT NULL DEFAULT 0,
    total_deductions            INTEGER NOT NULL DEFAULT 0,
    net_pay                     INTEGER NOT NULL DEFAULT 0,
    
    -- 計算詳細
    calculation_details         JSONB,
    
    -- 確定・取消情報
    confirmed_at                TIMESTAMP,
    confirmed_by                BIGINT REFERENCES users(id),
    cancelled_at                TIMESTAMP,
    cancelled_by                BIGINT REFERENCES users(id),
    cancellation_reason         TEXT,
    
    -- PDF
    pdf_path                    TEXT,
    
    created_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT chk_payroll_records_amounts CHECK (
        total_earnings >= 0 AND 
        total_deductions >= 0 AND 
        net_pay = total_earnings - total_deductions
    )
);

CREATE INDEX idx_payroll_records_group ON payroll_records(payroll_record_group_id);
CREATE INDEX idx_payroll_records_employee ON payroll_records(employee_id);
CREATE INDEX idx_payroll_records_period ON payroll_records(payroll_period_id);
CREATE INDEX idx_payroll_records_status ON payroll_records(company_id, status);

-- RLS設定
ALTER TABLE payroll_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_records FORCE ROW LEVEL SECURITY;
```

#### payroll_record_items（給与明細項目）

```sql
CREATE TABLE payroll_record_items (
    id                          BIGSERIAL PRIMARY KEY,
    company_id                  BIGINT NOT NULL,
    payroll_record_id           BIGINT NOT NULL REFERENCES payroll_records(id) ON DELETE CASCADE,
    
    item_type                   TEXT NOT NULL CHECK (item_type IN ('earning', 'deduction')),
    item_code                   TEXT NOT NULL,
    item_name                   TEXT NOT NULL,
    
    amount                      INTEGER NOT NULL,
    quantity                    NUMERIC(10,2),
    unit_price                  NUMERIC(10,2),
    
    is_taxable                  BOOLEAN DEFAULT true,
    is_social_insurance_target  BOOLEAN DEFAULT true,
    is_employment_insurance_target BOOLEAN DEFAULT true,
    
    display_order               INTEGER,
    notes                       TEXT,
    
    created_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payroll_items_record ON payroll_record_items(payroll_record_id);
CREATE INDEX idx_payroll_items_type ON payroll_record_items(payroll_record_id, item_type);

-- RLS設定
ALTER TABLE payroll_record_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_record_items FORCE ROW LEVEL SECURITY;
```

#### payroll_snapshots（給与スナップショット）

```sql
CREATE TABLE payroll_snapshots (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    payroll_record_id       BIGINT NOT NULL REFERENCES payroll_records(id) ON DELETE RESTRICT,
    snapshot_data           JSONB NOT NULL,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payroll_snapshots_record ON payroll_snapshots(payroll_record_id);

-- RLS設定
ALTER TABLE payroll_snapshots ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_snapshots FORCE ROW LEVEL SECURITY;
```

#### payroll_histories（給与履歴）

```sql
CREATE TABLE payroll_histories (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    payroll_record_id       BIGINT NOT NULL REFERENCES payroll_records(id) ON DELETE CASCADE,
    action                  TEXT NOT NULL,
    changed_by              BIGINT REFERENCES users(id),
    old_values              JSONB,
    new_values              JSONB,
    reason                  TEXT,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payroll_histories_record ON payroll_histories(payroll_record_id);
CREATE INDEX idx_payroll_histories_created ON payroll_histories(created_at DESC);

-- RLS設定
ALTER TABLE payroll_histories ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_histories FORCE ROW LEVEL SECURITY;
```

---

### 3.7 賞与関連

#### bonus_events（賞与イベント）

```sql
CREATE TABLE bonus_events (
    id              BIGSERIAL PRIMARY KEY,
    company_id      BIGINT NOT NULL,
    bonus_name      TEXT NOT NULL,
    payment_date    DATE NOT NULL,
    status          TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'confirmed', 'paid')),
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bonus_events_company ON bonus_events(company_id);

-- RLS設定
ALTER TABLE bonus_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE bonus_events FORCE ROW LEVEL SECURITY;
```

#### bonus_records（賞与明細）

```sql
CREATE TABLE bonus_records (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    bonus_event_id          BIGINT NOT NULL REFERENCES bonus_events(id) ON DELETE RESTRICT,
    employee_id             BIGINT NOT NULL REFERENCES employees(id) ON DELETE RESTRICT,
    
    bonus_amount            INTEGER NOT NULL,
    
    -- 社会保険料
    health_insurance        INTEGER DEFAULT 0,
    pension_insurance       INTEGER DEFAULT 0,
    employment_insurance    INTEGER DEFAULT 0,
    
    -- 税金
    income_tax              INTEGER DEFAULT 0,
    resident_tax            INTEGER DEFAULT 0,
    
    net_bonus               INTEGER NOT NULL,
    
    calculation_details     JSONB,
    pdf_path                TEXT,
    
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_bonus_records UNIQUE (bonus_event_id, employee_id)
);

CREATE INDEX idx_bonus_records_event ON bonus_records(bonus_event_id);
CREATE INDEX idx_bonus_records_employee ON bonus_records(employee_id);

-- RLS設定
ALTER TABLE bonus_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE bonus_records FORCE ROW LEVEL SECURITY;
```

---

### 3.8 年末調整関連

#### year_end_adjustments（年末調整）

```sql
CREATE TABLE year_end_adjustments (
    id                              BIGSERIAL PRIMARY KEY,
    company_id                      BIGINT NOT NULL,
    employee_id                     BIGINT NOT NULL REFERENCES employees(id) ON DELETE RESTRICT,
    target_year                     INTEGER NOT NULL,
    
    status                          TEXT NOT NULL DEFAULT 'draft' 
                                    CHECK (status IN ('draft', 'submitted', 'returned', 'approved', 'confirmed')),
    
    -- 控除情報
    basic_deduction                 INTEGER DEFAULT 0,
    spouse_deduction                INTEGER DEFAULT 0,
    dependent_deduction             INTEGER DEFAULT 0,
    disability_deduction            INTEGER DEFAULT 0,
    widow_deduction                 INTEGER DEFAULT 0,
    working_student_deduction       INTEGER DEFAULT 0,
    social_insurance_premium        INTEGER DEFAULT 0,
    small_business_mutual_aid       INTEGER DEFAULT 0,
    life_insurance_premium          INTEGER DEFAULT 0,
    earthquake_insurance_premium    INTEGER DEFAULT 0,
    housing_loan_deduction          INTEGER DEFAULT 0,
    
    -- 精算情報
    annual_income                   INTEGER,
    annual_withheld_tax             INTEGER,
    annual_calculated_tax           INTEGER,
    adjustment_amount               INTEGER,
    
    -- 申告情報
    spouse_info                     JSONB,
    dependent_info                  JSONB,
    insurance_info                  JSONB,
    
    -- 日時
    submitted_at                    TIMESTAMP,
    returned_at                     TIMESTAMP,
    return_reason                   TEXT,
    approved_at                     TIMESTAMP,
    approved_by                     BIGINT REFERENCES users(id),
    confirmed_at                    TIMESTAMP,
    confirmed_by                    BIGINT REFERENCES users(id),
    
    created_at                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at                      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_year_end_adjustments UNIQUE (company_id, employee_id, target_year)
);

CREATE INDEX idx_year_end_adjustments_employee ON year_end_adjustments(employee_id);
CREATE INDEX idx_year_end_adjustments_year ON year_end_adjustments(company_id, target_year);

-- RLS設定
ALTER TABLE year_end_adjustments ENABLE ROW LEVEL SECURITY;
ALTER TABLE year_end_adjustments FORCE ROW LEVEL SECURITY;
```

#### year_end_adjustment_histories（年末調整履歴）

```sql
CREATE TABLE year_end_adjustment_histories (
    id                          BIGSERIAL PRIMARY KEY,
    company_id                  BIGINT NOT NULL,
    year_end_adjustment_id      BIGINT NOT NULL REFERENCES year_end_adjustments(id) ON DELETE CASCADE,
    action                      TEXT NOT NULL,
    changed_by                  BIGINT REFERENCES users(id),
    old_status                  TEXT,
    new_status                  TEXT,
    reason                      TEXT,
    created_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_yea_histories_adjustment ON year_end_adjustment_histories(year_end_adjustment_id);

-- RLS設定
ALTER TABLE year_end_adjustment_histories ENABLE ROW LEVEL SECURITY;
ALTER TABLE year_end_adjustment_histories FORCE ROW LEVEL SECURITY;
```

#### deduction_certificates（控除証明書）

```sql
CREATE TABLE deduction_certificates (
    id                          BIGSERIAL PRIMARY KEY,
    company_id                  BIGINT NOT NULL,
    year_end_adjustment_id      BIGINT NOT NULL REFERENCES year_end_adjustments(id) ON DELETE CASCADE,
    certificate_type            TEXT NOT NULL,
    file_path                   TEXT NOT NULL,
    file_name                   TEXT NOT NULL,
    file_size                   BIGINT,
    uploaded_at                 TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_deduction_certificates_adjustment ON deduction_certificates(year_end_adjustment_id);

-- RLS設定
ALTER TABLE deduction_certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE deduction_certificates FORCE ROW LEVEL SECURITY;
```

#### tax_withholding_slips（源泉徴収票）

```sql
CREATE TABLE tax_withholding_slips (
    id                          BIGSERIAL PRIMARY KEY,
    company_id                  BIGINT NOT NULL,
    year_end_adjustment_id      BIGINT NOT NULL REFERENCES year_end_adjustments(id) ON DELETE RESTRICT,
    employee_id                 BIGINT NOT NULL REFERENCES employees(id) ON DELETE RESTRICT,
    target_year                 INTEGER NOT NULL,
    issue_date                  DATE NOT NULL,
    
    -- 源泉徴収票データ
    slip_data                   JSONB NOT NULL,
    pdf_path                    TEXT,
    
    created_at                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_tax_withholding_slips UNIQUE (year_end_adjustment_id)
);

CREATE INDEX idx_tax_withholding_slips_employee ON tax_withholding_slips(employee_id);

-- RLS設定
ALTER TABLE tax_withholding_slips ENABLE ROW LEVEL SECURITY;
ALTER TABLE tax_withholding_slips FORCE ROW LEVEL SECURITY;
```

---

### 3.9 通知・連携関連

#### payroll_notification_tokens（明細通知トークン）

```sql
CREATE TABLE payroll_notification_tokens (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    payroll_record_id       BIGINT NOT NULL REFERENCES payroll_records(id) ON DELETE CASCADE,
    token_hash              TEXT NOT NULL UNIQUE,
    expires_at              TIMESTAMP NOT NULL,
    accessed_at             TIMESTAMP,
    access_count            INTEGER DEFAULT 0,
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notification_tokens_record ON payroll_notification_tokens(payroll_record_id);
CREATE INDEX idx_notification_tokens_hash ON payroll_notification_tokens(token_hash);
CREATE INDEX idx_notification_tokens_expires ON payroll_notification_tokens(expires_at);

-- RLS設定
ALTER TABLE payroll_notification_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE payroll_notification_tokens FORCE ROW LEVEL SECURITY;
```

#### accounting_mappings（会計科目マッピング）

```sql
CREATE TABLE accounting_mappings (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    item_type               TEXT NOT NULL CHECK (item_type IN ('earning', 'deduction')),
    item_code               TEXT NOT NULL,
    account_code            TEXT NOT NULL,
    account_name            TEXT NOT NULL,
    sub_account_code        TEXT,
    sub_account_name        TEXT,
    debit_credit            TEXT CHECK (debit_credit IN ('debit', 'credit')),
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    CONSTRAINT uk_accounting_mappings UNIQUE (company_id, item_type, item_code)
);

CREATE INDEX idx_accounting_mappings_company ON accounting_mappings(company_id);

-- RLS設定
ALTER TABLE accounting_mappings ENABLE ROW LEVEL SECURITY;
ALTER TABLE accounting_mappings FORCE ROW LEVEL SECURITY;
```

#### bank_transfer_exports（銀行振込データ）

```sql
CREATE TABLE bank_transfer_exports (
    id                      BIGSERIAL PRIMARY KEY,
    company_id              BIGINT NOT NULL,
    export_date             DATE NOT NULL,
    payment_date            DATE NOT NULL,
    file_path               TEXT NOT NULL,
    record_count            INTEGER NOT NULL,
    total_amount            BIGINT NOT NULL,
    created_by              BIGINT REFERENCES users(id),
    created_at              TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bank_transfer_exports_company ON bank_transfer_exports(company_id);
CREATE INDEX idx_bank_transfer_exports_date ON bank_transfer_exports(export_date);

-- RLS設定
ALTER TABLE bank_transfer_exports ENABLE ROW LEVEL SECURITY;
ALTER TABLE bank_transfer_exports FORCE ROW LEVEL SECURITY;
```

---

### 3.10 監査ログ

#### audit_logs（監査ログ）

```sql
CREATE TABLE audit_logs (
    id              BIGSERIAL PRIMARY KEY,
    company_id      BIGINT,
    user_id         BIGINT REFERENCES users(id) ON DELETE SET NULL,
    action          TEXT NOT NULL,
    table_name      TEXT,
    record_id       BIGINT,
    old_values      JSONB,
    new_values      JSONB,
    ip_address      INET,
    user_agent      TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_logs_company ON audit_logs(company_id);
CREATE INDEX idx_audit_logs_user ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_table ON audit_logs(table_name, record_id);
CREATE INDEX idx_audit_logs_created ON audit_logs(created_at DESC);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);

-- RLS設定
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs FORCE ROW LEVEL SECURITY;
```

---

## 4. RLSポリシー定義

### 4.1 共通関数

```sql
-- 現在の会社IDを取得
CREATE OR REPLACE FUNCTION app_current_company_id()
RETURNS BIGINT AS $$
BEGIN
    RETURN current_setting('app.current_company_id', true)::BIGINT;
EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
END;
$$ LANGUAGE plpgsql STABLE;

-- スーパー管理者判定
CREATE OR REPLACE FUNCTION app_is_super_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN COALESCE(current_setting('app.is_super_admin', true)::BOOLEAN, false);
EXCEPTION WHEN OTHERS THEN
    RETURN false;
END;
$$ LANGUAGE plpgsql STABLE;
```

### 4.2 ポリシー適用例（employees）

```sql
-- 一般ユーザー用（自社データのみ）
CREATE POLICY employees_tenant_isolation ON employees
    FOR ALL
    TO app_user
    USING (company_id = app_current_company_id())
    WITH CHECK (company_id = app_current_company_id());

-- スーパー管理者用（全データ）
CREATE POLICY employees_super_admin ON employees
    FOR ALL
    TO app_user
    USING (app_is_super_admin());
```

---

## 5. インデックス最適化

### 5.1 複合インデックス

```sql
-- 給与明細検索最適化
CREATE INDEX idx_payroll_records_company_status_payment 
    ON payroll_records(company_id, status, payment_date DESC);

-- 勤怠データ検索最適化
CREATE INDEX idx_attendance_company_year_month 
    ON attendance_records(company_id, year_month DESC);

-- 年末調整検索最適化
CREATE INDEX idx_yea_company_year_status 
    ON year_end_adjustments(company_id, target_year, status);
```

---

**文書終了**
