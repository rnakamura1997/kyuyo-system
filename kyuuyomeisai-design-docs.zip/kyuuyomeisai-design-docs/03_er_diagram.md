# ER図とデータモデル設計

**文書バージョン**: v1.0  
**作成日**: 2026-02-09

---

## 1. ER図（Entity Relationship Diagram）

### 1.1 全体ER図

```mermaid
erDiagram
    companies ||--o{ employees : "employs"
    companies ||--o{ payroll_periods : "has"
    companies ||--o{ bonus_events : "has"
    companies ||--o{ accounting_mappings : "has"
    
    employees ||--o{ attendance_records : "has"
    employees ||--o{ payroll_records : "has"
    employees ||--o{ bonus_records : "has"
    employees ||--o{ year_end_adjustments : "has"
    employees ||--o{ employee_allowances : "has"
    employees ||--o{ commute_details : "has"
    
    users ||--o{ user_roles : "has"
    users }o--|| companies : "belongs to"
    roles ||--o{ user_roles : "has"
    
    payroll_periods ||--o{ payroll_record_groups : "has"
    payroll_record_groups ||--|| payroll_records : "current version"
    payroll_record_groups ||--o{ payroll_records : "all versions"
    payroll_records ||--o{ payroll_record_items : "has"
    payroll_records ||--o{ payroll_snapshots : "has"
    payroll_records ||--o{ payroll_histories : "has"
    
    bonus_events ||--o{ bonus_records : "has"
    
    year_end_adjustments ||--o{ year_end_adjustment_histories : "has"
    year_end_adjustments ||--o{ deduction_certificates : "has"
    year_end_adjustments ||--|| tax_withholding_slips : "generates"
    
    income_tax_tables ||--o{ payroll_records : "references"
    insurance_rates ||--o{ payroll_records : "references"
    commute_tax_limits ||--o{ commute_details : "references"
    
    payroll_records ||--o{ payroll_notification_tokens : "notifies"
    payroll_records ||--o{ bank_transfer_exports : "exports"
```

### 1.2 コアエンティティ関係図

```mermaid
erDiagram
    companies {
        bigserial id PK
        text name
        text address
        text legal_number
        text logo_path
        integer closing_day
        integer payment_day
        jsonb settings
        boolean is_deleted
    }
    
    employees {
        bigserial id PK
        bigint company_id FK
        text employee_code
        text first_name
        text last_name
        text email
        date hire_date
        date termination_date
        text employment_type
        text salary_type
        jsonb salary_settings
        text tax_category
        integer dependents_count
        boolean is_deleted
    }
    
    payroll_records {
        bigserial id PK
        bigint company_id FK
        bigint payroll_record_group_id FK
        bigint employee_id FK
        bigint payroll_period_id FK
        integer version
        text status
        date payment_date
        integer total_earnings
        integer total_deductions
        integer net_pay
        jsonb calculation_details
        timestamp confirmed_at
        bigint confirmed_by
    }
    
    attendance_records {
        bigserial id PK
        bigint company_id FK
        bigint employee_id FK
        integer year_month
        integer work_days
        integer attendance_days
        integer regular_hours
        integer overtime_hours
        integer night_hours
        integer holiday_hours
        jsonb detailed_hours
    }
```

---

## 2. データモデル設計方針

### 2.1 命名規則

#### テーブル名
- **形式**: 複数形、スネークケース
- **例**: `employees`, `payroll_records`, `tax_withholding_slips`

#### カラム名
- **形式**: スネークケース
- **ID**: `id`（主キー）、`xxx_id`（外部キー）
- **タイムスタンプ**: `created_at`, `updated_at`
- **論理削除**: `is_deleted`
- **会社ID**: `company_id`（マルチテナント）

### 2.2 共通カラム

全テーブルに以下のカラムを含める：

```sql
id              bigserial PRIMARY KEY
company_id      bigint    -- マルチテナント用（例外: グローバルテーブル）
created_at      timestamp DEFAULT CURRENT_TIMESTAMP
updated_at      timestamp DEFAULT CURRENT_TIMESTAMP
is_deleted      boolean   DEFAULT false
```

### 2.3 データ型の統一

| 用途 | データ型 | 理由 |
|------|---------|------|
| 主キー | bigserial | 将来的な拡張性 |
| 金額 | integer | 円単位、小数点不要 |
| 時間 | integer | 分単位、丸め誤差回避 |
| 日付 | date | 日付のみ |
| タイムスタンプ | timestamp | 日時 |
| メールアドレス | citext | 大文字小文字区別なし |
| JSON | jsonb | インデックス可能 |
| テキスト | text | 可変長 |
| フラグ | boolean | true/false |

### 2.4 インデックス戦略

#### 自動作成されるインデックス
- 主キー（id）
- UNIQUE制約

#### 追加作成が必要なインデックス
- 外部キー（company_id, employee_id等）
- 検索条件に使用するカラム
- ソートに使用するカラム
- 複合インデックス（頻繁に組み合わせて検索する場合）

**例**:
```sql
CREATE INDEX idx_employees_company_id ON employees(company_id) WHERE is_deleted = false;
CREATE INDEX idx_payroll_records_employee_period ON payroll_records(employee_id, payroll_period_id);
CREATE INDEX idx_attendance_records_year_month ON attendance_records(company_id, year_month);
```

---

## 3. マルチテナント実装

### 3.1 Row-level分離方式

#### 原則
- 全テーブルに `company_id` カラムを保持
- PostgreSQL RLSで自動フィルタリング
- アプリケーション側でも二重チェック

#### 例外（グローバルテーブル）
- `roles`: ロール定義
- `income_tax_tables`: 所得税額表
- `commute_tax_limits`: 通勤手当非課税限度額
- `system_settings`: システム設定
- `insurance_constants`: 社会保険定数

### 3.2 RLS（Row Level Security）実装

```sql
-- RLS有効化
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees FORCE ROW LEVEL SECURITY;

-- 一般ユーザー用ポリシー（自社データのみ）
CREATE POLICY employees_tenant_isolation ON employees
    FOR ALL
    TO app_user
    USING (company_id = current_setting('app.current_company_id')::bigint)
    WITH CHECK (company_id = current_setting('app.current_company_id')::bigint);

-- スーパー管理者用ポリシー（全データ）
CREATE POLICY employees_super_admin ON employees
    FOR ALL
    TO app_user
    USING (
        current_setting('app.is_super_admin', true)::boolean = true
    );
```

### 3.3 セッション変数設定

FastAPI側での実装：

```python
async def set_rls_context(
    db: AsyncSession,
    current_user: User
):
    """RLSコンテキストを設定"""
    await db.execute(
        text("SET LOCAL app.current_company_id = :company_id"),
        {"company_id": current_user.company_id}
    )
    await db.execute(
        text("SET LOCAL app.is_super_admin = :is_super_admin"),
        {"is_super_admin": current_user.is_super_admin}
    )
```

---

## 4. 主要エンティティ詳細

### 4.1 会社マスタ（companies）

**目的**: 複数会社の基本情報を管理

**主要カラム**:
- `id`: 会社ID（主キー）
- `name`: 会社名
- `address`: 住所
- `legal_number`: 法人番号
- `logo_path`: ロゴ画像パス
- `closing_day`: 締め日（1-31）
- `payment_day`: 支払日（1-31）
- `health_insurance_type`: 健康保険種別（協会けんぽ/組合）
- `health_insurance_prefecture`: 都道府県
- `health_insurance_union_name`: 組合名
- `business_office_symbol`: 事業所整理記号
- `pension_office_number`: 厚生年金事業所番号
- `employment_office_number`: 雇用保険事業所番号
- `employment_business_type`: 事業種別
- `settings`: その他設定（JSONB）

### 4.2 従業員マスタ（employees）

**目的**: 従業員の基本情報・給与設定を管理

**主要カラム**:
- `id`: 従業員ID（主キー）
- `company_id`: 会社ID（外部キー）
- `employee_code`: 従業員コード（会社内で一意）
- `first_name`, `last_name`: 氏名
- `first_name_kana`, `last_name_kana`: カナ
- `email`: メールアドレス（citext）
- `birth_date`: 生年月日
- `gender`: 性別
- `address`: 住所
- `phone`: 電話番号
- `hire_date`: 入社日
- `termination_date`: 退職日
- `employment_type`: 雇用形態（正社員/契約/パート等）
- `department`: 部署
- `position`: 役職
- `salary_type`: 給与形態（daily/hourly/monthly/commission）
- `salary_settings`: 給与設定（JSONB）
  - 日給額、時給額、月給額等
  - 歩合計算設定
- `tax_category`: 税区分（kou/otsu/hei）
- `dependents_count`: 扶養親族数
- `social_insurance_enrolled`: 社会保険加入フラグ
- `employment_insurance_enrolled`: 雇用保険加入フラグ
- `resident_tax_type`: 住民税徴収区分
- `bank_name`, `branch_name`: 銀行情報
- `account_type`, `account_number`: 口座情報
- `account_holder`: 口座名義

### 4.3 勤怠データ（attendance_records）

**目的**: 月次の勤怠データを管理

**主要カラム**:
- `id`: 勤怠レコードID
- `company_id`, `employee_id`: 関連ID
- `year_month`: 対象年月（YYYYMM形式 integer）
- `statutory_work_days`: 所定労働日数
- `work_days`: 出勤日数
- `absence_days`: 欠勤日数
- `late_count`: 遅刻回数
- `early_leave_count`: 早退回数
- `paid_leave_days`: 有給休暇日数
- `substitute_holiday_days`: 代休日数
- **労働時間（分単位 integer）**:
  - `total_work_minutes`: 実労働時間
  - `regular_minutes`: 所定内労働時間
  - `overtime_within_statutory_minutes`: 所定外（法定内）
  - `overtime_statutory_minutes`: 法定時間外労働
  - `night_minutes`: 深夜労働
  - `statutory_holiday_minutes`: 法定休日労働
  - `non_statutory_holiday_minutes`: 法定外休日労働
  - `night_overtime_minutes`: 深夜×時間外（重複）
  - `night_holiday_minutes`: 深夜×休日（重複）
  - `night_overtime_holiday_minutes`: 深夜×時間外×休日（重複）

### 4.4 給与期間（payroll_periods）

**目的**: 給与計算の対象期間を管理

**主要カラム**:
- `id`: 期間ID
- `company_id`: 会社ID
- `period_type`: 期間種別（monthly/weekly/daily）
- `year_month`: 対象年月（YYYYMM）
- `start_date`, `end_date`: 期間
- `payment_date`: 支払日
- `closing_date`: 締め日
- `weekly_closing_day`: 週次の締め曜日（0-6）
- `status`: 状態（draft/confirmed/paid）

### 4.5 給与明細（payroll_records）

**目的**: 給与計算結果を管理（版管理あり）

**版管理の構造**:
- `payroll_record_groups`: 給与明細のグループ（従業員×期間で一意）
- `payroll_records`: 実際の給与明細（版ごとに作成）

**payroll_record_groups**:
- `id`: グループID
- `company_id`, `employee_id`, `payroll_period_id`: 関連ID
- `current_payroll_record_id`: 現在有効な版のID

**payroll_records**:
- `id`: 明細ID
- `payroll_record_group_id`: グループID
- `version`: 版番号（1, 2, 3...）
- `status`: 状態（draft/confirmed/cancelled）
- `payment_date`: 支払日
- **金額（円単位 integer）**:
  - `total_earnings`: 総支給額
  - `total_deductions`: 総控除額
  - `net_pay`: 差引支給額
- `calculation_details`: 計算詳細（JSONB）
  - 各支給項目・控除項目の内訳
- `confirmed_at`, `confirmed_by`: 確定日時・確定者
- `cancelled_at`, `cancelled_by`: 取消日時・取消者

### 4.6 給与明細項目（payroll_record_items）

**目的**: 給与明細の明細行（支給/控除）

**主要カラム**:
- `id`: 項目ID
- `payroll_record_id`: 明細ID
- `item_type`: 種別（earning/deduction）
- `item_code`: 項目コード（basic_salary, overtime_pay等）
- `item_name`: 項目名
- `amount`: 金額（円）
- `quantity`: 数量（時間数、日数等）
- `unit_price`: 単価
- `is_taxable`: 課税対象フラグ
- `is_social_insurance_target`: 社会保険対象フラグ

### 4.7 給与スナップショット（payroll_snapshots）

**目的**: 確定時の計算根拠を保存（再現性担保）

**主要カラム**:
- `id`: スナップショットID
- `payroll_record_id`: 明細ID
- `snapshot_data`: スナップショットデータ（JSONB）
  - 参照した料率テーブル
  - 参照した税額表
  - 従業員情報のスナップショット
  - 勤怠データのスナップショット
  - 計算ロジックのバージョン

### 4.8 賞与（bonus_events, bonus_records）

**bonus_events**:
- `id`: 賞与イベントID
- `company_id`: 会社ID
- `bonus_name`: 賞与名（夏季賞与、年末賞与等）
- `payment_date`: 支給日
- `status`: 状態

**bonus_records**:
- `id`: 賞与明細ID
- `bonus_event_id`: 賞与イベントID
- `employee_id`: 従業員ID
- `bonus_amount`: 賞与額
- **社会保険料**:
  - `health_insurance`: 健康保険料
  - `pension_insurance`: 厚生年金保険料
  - `employment_insurance`: 雇用保険料
- `income_tax`: 所得税
- `net_bonus`: 差引支給額

### 4.9 年末調整（year_end_adjustments）

**目的**: 年末調整データを管理

**主要カラム**:
- `id`: 年末調整ID
- `company_id`, `employee_id`: 関連ID
- `target_year`: 対象年
- `status`: 状態（draft/submitted/returned/approved/confirmed）
- **控除情報**:
  - `basic_deduction`: 基礎控除
  - `spouse_deduction`: 配偶者控除
  - `dependent_deduction`: 扶養控除
  - `disability_deduction`: 障害者控除
  - `social_insurance_premium`: 社会保険料控除
  - `life_insurance_premium`: 生命保険料控除
  - `earthquake_insurance_premium`: 地震保険料控除
  - `housing_loan_deduction`: 住宅ローン控除
- **精算情報**:
  - `annual_income`: 年間給与収入
  - `annual_withheld_tax`: 年間源泉徴収税額
  - `annual_calculated_tax`: 年間所得税額
  - `adjustment_amount`: 過不足額
- `submitted_at`, `approved_at`, `confirmed_at`: 各日時

### 4.10 源泉徴収票（tax_withholding_slips）

**目的**: 源泉徴収票データを管理

**主要カラム**:
- `id`: 源泉徴収票ID
- `year_end_adjustment_id`: 年末調整ID
- `issue_date`: 発行日
- `pdf_path`: PDFファイルパス
- **記載内容**（年末調整データから生成）

---

## 5. 料率・税額テーブル

### 5.1 所得税額表（income_tax_tables）

**目的**: 源泉徴収税額表を時系列管理

**主要カラム**:
- `id`: レコードID
- `table_type`: 表種別（monthly_kou/daily_kou/otsu/hei）
- `valid_from`, `valid_to`: 有効期間
- `income_from`, `income_to`: 課税対象額範囲
- `dependents_count`: 扶養親族数
- `tax_amount`: 税額

**特徴**:
- 年度ごとに新しいレコードを追加
- 過去の計算を再現可能

### 5.2 社会保険料率（insurance_rates）

**目的**: 健康保険・厚生年金・雇用保険の料率を時系列管理

**主要カラム**:
- `id`: レコードID
- `insurance_type`: 保険種別（health/pension/employment）
- `valid_from`, `valid_to`: 有効期間
- `prefecture`: 都道府県（健康保険用）
- `business_type`: 事業種別（雇用保険用）
- `employee_rate`: 従業員負担率
- `employer_rate`: 事業主負担率
- `care_insurance_rate`: 介護保険料率（40歳以上）

### 5.3 通勤手当非課税限度額（commute_tax_limits）

**目的**: 通勤手当の非課税限度額を管理

**主要カラム**:
- `id`: レコードID
- `valid_from`, `valid_to`: 有効期間
- `commute_type`: 通勤方法
- `distance_from`, `distance_to`: 距離範囲（km）
- `limit_amount`: 非課税限度額

---

## 6. その他の重要テーブル

### 6.1 ユーザー・権限

**users**:
- ユーザーアカウント情報
- パスワードハッシュ
- 所属会社

**roles**:
- ロール定義（super_admin/admin/accountant/employee）

**user_roles**:
- ユーザーとロールの紐付け

### 6.2 手当マスタ（allowance_types）

**目的**: 会社ごとの手当種別を管理

**主要カラム**:
- `id`, `company_id`
- `code`: 手当コード
- `name`: 手当名
- `is_taxable`: 課税対象フラグ
- `is_social_insurance_target`: 社会保険対象フラグ
- `is_overtime_base`: 残業計算の基礎に含めるか
- `is_active`: 運用状態

### 6.3 通勤詳細（commute_details）

**目的**: 従業員ごとの通勤情報を管理

**主要カラム**:
- `employee_id`
- `commute_method`: 通勤方法
- `distance`: 距離（km）
- `route`: 定期券区間
- `monthly_cost`: 定期券代
- `non_taxable_limit`: 非課税限度額（自動計算）

### 6.4 監査ログ（audit_logs）

**目的**: 全操作の履歴を記録

**主要カラム**:
- `id`
- `user_id`: 操作者
- `action`: アクション（login/create/update/delete等）
- `table_name`: 対象テーブル
- `record_id`: 対象レコードID
- `old_values`, `new_values`: 変更前後の値（JSONB）
- `ip_address`: IPアドレス
- `user_agent`: ユーザーエージェント
- `created_at`: 操作日時

### 6.5 メール通知トークン（payroll_notification_tokens）

**目的**: 給与明細閲覧用のトークンを管理

**主要カラム**:
- `id`
- `payroll_record_id`: 給与明細ID
- `token_hash`: トークンハッシュ
- `expires_at`: 有効期限（30日間）
- `accessed_at`: 最終アクセス日時

---

## 7. データ整合性制約

### 7.1 外部キー制約

全ての外部キー関係に制約を設定：

```sql
ALTER TABLE employees
    ADD CONSTRAINT fk_employees_company
    FOREIGN KEY (company_id) REFERENCES companies(id)
    ON DELETE RESTRICT;  -- 削除禁止（論理削除を使用）
```

### 7.2 UNIQUE制約

```sql
-- 従業員コードは会社内で一意
ALTER TABLE employees
    ADD CONSTRAINT uk_employees_company_code
    UNIQUE (company_id, employee_code);

-- 給与明細グループは従業員×期間で一意
ALTER TABLE payroll_record_groups
    ADD CONSTRAINT uk_payroll_groups
    UNIQUE (company_id, employee_id, payroll_period_id);
```

### 7.3 CHECK制約

```sql
-- 金額は0以上
ALTER TABLE payroll_records
    ADD CONSTRAINT chk_payroll_records_amounts
    CHECK (total_earnings >= 0 AND total_deductions >= 0);

-- 締め日は1-31
ALTER TABLE companies
    ADD CONSTRAINT chk_companies_closing_day
    CHECK (closing_day BETWEEN 1 AND 31);

-- 税区分は所定の値のみ
ALTER TABLE employees
    ADD CONSTRAINT chk_employees_tax_category
    CHECK (tax_category IN ('kou', 'otsu', 'hei'));
```

---

## 8. パーティショニング戦略（将来的検討）

大量データ蓄積時のパフォーマンス対策として、以下のテーブルをパーティショニング：

### 対象テーブル
- `payroll_records`: 年月でパーティション
- `attendance_records`: 年月でパーティション
- `audit_logs`: 年でパーティション

### 例（payroll_recordsの年パーティション）

```sql
CREATE TABLE payroll_records (
    ...
) PARTITION BY RANGE (EXTRACT(YEAR FROM payment_date));

CREATE TABLE payroll_records_2026 PARTITION OF payroll_records
    FOR VALUES FROM (2026) TO (2027);
```

---

**文書終了**
