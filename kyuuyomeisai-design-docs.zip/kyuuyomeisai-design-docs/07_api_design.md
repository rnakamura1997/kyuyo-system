# API設計書

**文書バージョン**: v1.0  
**作成日**: 2026-02-09

---

## 1. API概要

### 1.1 基本情報
- **ベースURL**: `https://yourdomain.com/api/v1`
- **プロトコル**: HTTPS
- **認証方式**: JWT（httpOnly Cookie）
- **データ形式**: JSON
- **文字コード**: UTF-8

### 1.2 共通ヘッダー

| ヘッダー | 説明 | 必須 |
|---------|------|------|
| Content-Type | `application/json` | リクエスト時 |
| Authorization | `Bearer {token}` | 認証が必要なエンドポイント |

---

## 2. 認証API

### 2.1 ログイン

**エンドポイント**: `POST /auth/login`

**リクエスト**:
```json
{
  "username": "admin",
  "password": "password123"
}
```

**レスポンス（成功）**:
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "token_type": "bearer",
  "user": {
    "id": 1,
    "username": "admin",
    "email": "admin@example.com",
    "full_name": "管理者",
    "is_super_admin": true,
    "company_id": 1,
    "roles": ["super_admin"]
  }
}
```

**レスポンス（エラー）**:
```json
{
  "detail": "ユーザー名またはパスワードが正しくありません"
}
```

### 2.2 ログアウト

**エンドポイント**: `POST /auth/logout`

**レスポンス**:
```json
{
  "message": "ログアウトしました"
}
```

### 2.3 トークン更新

**エンドポイント**: `POST /auth/refresh`

**レスポンス**:
```json
{
  "access_token": "new_token...",
  "token_type": "bearer"
}
```

---

## 3. 会社管理API

### 3.1 会社一覧取得

**エンドポイント**: `GET /companies`

**クエリパラメータ**:
- `page`: ページ番号（デフォルト: 1）
- `limit`: 1ページあたりの件数（デフォルト: 20）
- `is_deleted`: 削除済みを含む（true/false）

**レスポンス**:
```json
{
  "items": [
    {
      "id": 1,
      "company_id": 1,
      "name": "株式会社サンプル",
      "address": "東京都...",
      "closing_day": 25,
      "payment_day": 10
    }
  ],
  "total": 1,
  "page": 1,
  "limit": 20
}
```

### 3.2 会社詳細取得

**エンドポイント**: `GET /companies/{company_id}`

### 3.3 会社作成

**エンドポイント**: `POST /companies`

**リクエスト**:
```json
{
  "name": "株式会社テスト",
  "address": "東京都渋谷区...",
  "closing_day": 25,
  "payment_day": 10,
  "health_insurance_type": "kyokai",
  "health_insurance_prefecture": "tokyo"
}
```

### 3.4 会社更新

**エンドポイント**: `PUT /companies/{company_id}`

### 3.5 会社削除（論理削除）

**エンドポイント**: `DELETE /companies/{company_id}`

---

## 4. 従業員管理API

### 4.1 従業員一覧取得

**エンドポイント**: `GET /employees`

**クエリパラメータ**:
- `company_id`: 会社ID
- `page`, `limit`: ページネーション
- `search`: 検索キーワード（氏名・コード）
- `employment_type`: 雇用形態フィルター
- `is_deleted`: 削除済みを含む

**レスポンス**:
```json
{
  "items": [
    {
      "id": 1,
      "company_id": 1,
      "employee_code": "EMP001",
      "first_name": "太郎",
      "last_name": "山田",
      "email": "taro@example.com",
      "hire_date": "2020-04-01",
      "employment_type": "正社員",
      "salary_type": "monthly"
    }
  ],
  "total": 50,
  "page": 1,
  "limit": 20
}
```

### 4.2 従業員詳細取得

**エンドポイント**: `GET /employees/{employee_id}`

### 4.3 従業員作成

**エンドポイント**: `POST /employees`

**リクエスト**:
```json
{
  "company_id": 1,
  "employee_code": "EMP002",
  "first_name": "花子",
  "last_name": "佐藤",
  "email": "hanako@example.com",
  "hire_date": "2023-01-01",
  "employment_type": "正社員",
  "salary_type": "monthly",
  "salary_settings": {
    "monthly_salary": 300000
  },
  "tax_category": "kou",
  "dependents_count": 2
}
```

### 4.4 従業員更新

**エンドポイント**: `PUT /employees/{employee_id}`

### 4.5 従業員削除（論理削除）

**エンドポイント**: `DELETE /employees/{employee_id}`

---

## 5. 勤怠データAPI

### 5.1 勤怠データ一覧取得

**エンドポイント**: `GET /attendance`

**クエリパラメータ**:
- `company_id`: 会社ID
- `employee_id`: 従業員ID
- `year_month`: 対象年月（YYYYMM）

### 5.2 勤怠データ登録/更新

**エンドポイント**: `POST /attendance`

**リクエスト**:
```json
{
  "company_id": 1,
  "employee_id": 1,
  "year_month": 202601,
  "work_days": 20,
  "regular_minutes": 9600,
  "overtime_statutory_minutes": 600,
  "night_minutes": 0
}
```

### 5.3 CSVインポート

**エンドポイント**: `POST /attendance/import`

**リクエスト**: multipart/form-data
- `file`: CSVファイル
- `company_id`: 会社ID

---

## 6. 給与計算API

### 6.1 給与期間一覧

**エンドポイント**: `GET /payroll-periods`

### 6.2 給与期間作成

**エンドポイント**: `POST /payroll-periods`

**リクエスト**:
```json
{
  "company_id": 1,
  "period_type": "monthly",
  "year_month": 202601,
  "start_date": "2025-12-26",
  "end_date": "2026-01-25",
  "payment_date": "2026-02-10",
  "closing_date": "2026-01-25"
}
```

### 6.3 給与計算実行

**エンドポイント**: `POST /payroll/calculate`

**リクエスト**:
```json
{
  "payroll_period_id": 1,
  "employee_ids": [1, 2, 3]  // 空の場合は全従業員
}
```

**レスポンス**:
```json
{
  "job_id": "calc-12345",
  "status": "processing",
  "message": "給与計算を開始しました"
}
```

### 6.4 給与計算結果取得

**エンドポイント**: `GET /payroll/calculate/{job_id}`

### 6.5 給与明細一覧

**エンドポイント**: `GET /payroll-records`

**クエリパラメータ**:
- `company_id`, `employee_id`, `payroll_period_id`
- `status`: draft/confirmed/cancelled

### 6.6 給与明細詳細

**エンドポイント**: `GET /payroll-records/{record_id}`

**レスポンス**:
```json
{
  "id": 1,
  "employee": {
    "id": 1,
    "name": "山田 太郎"
  },
  "payment_date": "2026-02-10",
  "version": 1,
  "status": "confirmed",
  "total_earnings": 350000,
  "total_deductions": 80000,
  "net_pay": 270000,
  "items": [
    {
      "item_type": "earning",
      "item_code": "basic_salary",
      "item_name": "基本給",
      "amount": 300000
    },
    {
      "item_type": "deduction",
      "item_code": "income_tax",
      "item_name": "所得税",
      "amount": 15000
    }
  ]
}
```

### 6.7 給与明細確定

**エンドポイント**: `POST /payroll-records/{record_id}/confirm`

### 6.8 給与明細取消

**エンドポイント**: `POST /payroll-records/{record_id}/cancel`

**リクエスト**:
```json
{
  "reason": "計算誤りのため"
}
```

### 6.9 PDF出力

**エンドポイント**: `GET /payroll-records/{record_id}/pdf`

**レスポンス**: PDFバイナリ

### 6.10 一括PDF出力

**エンドポイント**: `POST /payroll-records/bulk-pdf`

**リクエスト**:
```json
{
  "payroll_period_id": 1,
  "employee_ids": [1, 2, 3]
}
```

**レスポンス**: ZIPファイル

---

## 7. 年末調整API

### 7.1 年末調整一覧

**エンドポイント**: `GET /year-end-adjustments`

### 7.2 年末調整詳細

**エンドポイント**: `GET /year-end-adjustments/{adjustment_id}`

### 7.3 年末調整作成/更新

**エンドポイント**: `POST /year-end-adjustments`

**リクエスト**:
```json
{
  "company_id": 1,
  "employee_id": 1,
  "target_year": 2025,
  "basic_deduction": 480000,
  "spouse_deduction": 380000,
  "dependent_deduction": 380000,
  "social_insurance_premium": 600000,
  "life_insurance_premium": 50000
}
```

### 7.4 年末調整提出

**エンドポイント**: `POST /year-end-adjustments/{adjustment_id}/submit`

### 7.5 年末調整承認

**エンドポイント**: `POST /year-end-adjustments/{adjustment_id}/approve`

### 7.6 年末調整差戻し

**エンドポイント**: `POST /year-end-adjustments/{adjustment_id}/return`

**リクエスト**:
```json
{
  "reason": "生命保険料控除証明書が不足しています"
}
```

### 7.7 証明書アップロード

**エンドポイント**: `POST /year-end-adjustments/{adjustment_id}/certificates`

**リクエスト**: multipart/form-data
- `file`: 証明書画像
- `certificate_type`: 証明書種別

### 7.8 源泉徴収票出力

**エンドポイント**: `GET /year-end-adjustments/{adjustment_id}/withholding-slip`

---

## 8. 帳票出力API

### 8.1 給与台帳

**エンドポイント**: `GET /reports/payroll-ledger`

**クエリパラメータ**:
- `company_id`, `year_month`
- `format`: pdf/excel/csv

### 8.2 銀行振込データ

**エンドポイント**: `POST /reports/bank-transfer`

**リクエスト**:
```json
{
  "payroll_period_id": 1,
  "format": "zengin"  // 全銀フォーマット
}
```

**レスポンス**: ZIPファイル（パスワード暗号化）

### 8.3 会計仕訳データ

**エンドポイント**: `POST /reports/accounting-journal`

**リクエスト**:
```json
{
  "payroll_period_id": 1,
  "format": "csv"
}
```

---

## 9. マスタ管理API

### 9.1 手当種別

**エンドポイント**: `GET /allowance-types`

### 9.2 料率テーブル

**エンドポイント**: `GET /insurance-rates`

### 9.3 所得税額表

**エンドポイント**: `GET /income-tax-tables`

---

## 10. エラーレスポンス

### 10.1 エラー形式

```json
{
  "detail": "エラーメッセージ",
  "error_code": "ERROR_CODE",
  "field_errors": {
    "email": ["正しいメールアドレスを入力してください"]
  }
}
```

### 10.2 HTTPステータスコード

| コード | 説明 |
|-------|------|
| 200 | 成功 |
| 201 | 作成成功 |
| 204 | 成功（レスポンスボディなし） |
| 400 | リクエストエラー |
| 401 | 認証エラー |
| 403 | 権限エラー |
| 404 | リソースが見つからない |
| 422 | バリデーションエラー |
| 500 | サーバーエラー |

---

## 11. ページネーション

### 11.1 共通仕様

**クエリパラメータ**:
- `page`: ページ番号（1始まり）
- `limit`: 1ページあたりの件数

**レスポンス**:
```json
{
  "items": [...],
  "total": 100,
  "page": 1,
  "limit": 20,
  "pages": 5
}
```

---

## 12. レート制限

- **認証なし**: 100リクエスト/時間
- **認証あり**: 1000リクエスト/時間

**超過時のレスポンス**:
```json
{
  "detail": "レート制限を超えました。しばらく待ってから再試行してください。"
}
```

---

**文書終了**
