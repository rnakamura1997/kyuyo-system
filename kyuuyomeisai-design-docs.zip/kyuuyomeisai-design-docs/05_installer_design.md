# インストーラー設計

**文書バージョン**: v1.0  
**作成日**: 2026-02-09

---

## 1. インストーラー概要

### 1.1 目的
給与明細管理システム（kyuuyomeisai）を自動的に環境構築し、初期設定を完了させるインストーラーを提供する。

### 1.2 インストーラーの機能
1. 環境チェック（前提条件確認）
2. 依存パッケージのインストール
3. データベース作成・初期化
4. 初期データ投入
5. 設定ファイル生成
6. サービス登録
7. Webサーバー設定

---

## 2. インストーラー実行形式

### 2.1 実行方法

```bash
# インストーラーのダウンロード
wget https://example.com/kyuuyomeisai-installer.sh

# 実行権限付与
chmod +x kyuuyomeisai-installer.sh

# インストーラー実行（root権限）
sudo ./kyuuyomeisai-installer.sh
```

### 2.2 インストーラー構成

```
kyuuyomeisai-installer/
├── install.sh                 # メインインストールスクリプト
├── config/
│   ├── env.template          # 環境変数テンプレート
│   ├── nginx.conf.template   # Nginx設定テンプレート
│   └── systemd.service       # Systemdサービス定義
├── sql/
│   ├── 01_create_database.sql
│   ├── 02_create_tables.sql
│   ├── 03_create_functions.sql
│   ├── 04_create_rls.sql
│   └── 05_initial_data.sql
├── backend/                   # Pythonバックエンド
└── frontend/                  # Reactフロントエンド（ビルド済み）
```

---

## 3. インストール手順

### 3.1 環境チェック

```bash
#!/bin/bash

echo "環境チェック中..."

# OSチェック
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS=$NAME
    VER=$VERSION_ID
else
    echo "エラー: サポートされていないOS"
    exit 1
fi

echo "OS: $OS $VER"

# Pythonバージョンチェック
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
REQUIRED_PYTHON="3.11"

if [ "$(printf '%s\n' "$REQUIRED_PYTHON" "$PYTHON_VERSION" | sort -V | head -n1)" != "$REQUIRED_PYTHON" ]; then
    echo "エラー: Python $REQUIRED_PYTHON 以上が必要です"
    exit 1
fi

echo "Python: $PYTHON_VERSION ✓"

# PostgreSQLチェック
if ! command -v psql &> /dev/null; then
    echo "警告: PostgreSQLクライアントがインストールされていません"
    read -p "PostgreSQLクライアントをインストールしますか？ (y/n): " install_psql
    if [ "$install_psql" = "y" ]; then
        apt-get update && apt-get install -y postgresql-client
    fi
fi

# Node.js/npmチェック（フロントエンドビルド用）
if ! command -v node &> /dev/null; then
    echo "警告: Node.jsがインストールされていません"
    echo "フロントエンドは事前ビルド版を使用します"
fi

echo "環境チェック完了 ✓"
```

### 3.2 依存パッケージインストール

```bash
#!/bin/bash

echo "依存パッケージをインストール中..."

# システムパッケージ
apt-get update
apt-get install -y \
    python3-pip \
    python3-venv \
    nginx \
    redis-server \
    git \
    build-essential \
    libpq-dev

# Pythonパッケージ（仮想環境）
python3 -m venv /opt/kyuuyomeisai/venv
source /opt/kyuuyomeisai/venv/bin/activate

pip install --upgrade pip
pip install -r /opt/kyuuyomeisai/backend/requirements.txt

echo "依存パッケージインストール完了 ✓"
```

### 3.3 データベース設定

```bash
#!/bin/bash

echo "データベース設定中..."

# 設定情報入力
read -p "PostgreSQLホスト [localhost]: " DB_HOST
DB_HOST=${DB_HOST:-localhost}

read -p "PostgreSQLポート [5432]: " DB_PORT
DB_PORT=${DB_PORT:-5432}

read -p "PostgreSQL管理者ユーザー [postgres]: " DB_ADMIN_USER
DB_ADMIN_USER=${DB_ADMIN_USER:-postgres}

read -sp "PostgreSQL管理者パスワード: " DB_ADMIN_PASS
echo

read -p "データベース名 [kyuuyomeisai]: " DB_NAME
DB_NAME=${DB_NAME:-kyuuyomeisai}

read -p "アプリ用ユーザー名 [kyuuyomeisai_app]: " DB_APP_USER
DB_APP_USER=${DB_APP_USER:-kyuuyomeisai_app}

read -sp "アプリ用ユーザーパスワード: " DB_APP_PASS
echo

# データベース作成
echo "データベースを作成中..."
PGPASSWORD=$DB_ADMIN_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_ADMIN_USER -c "CREATE DATABASE $DB_NAME;"

# アプリ用ユーザー作成
echo "アプリ用ユーザーを作成中..."
PGPASSWORD=$DB_ADMIN_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_ADMIN_USER -c "CREATE USER $DB_APP_USER WITH PASSWORD '$DB_APP_PASS';"
PGPASSWORD=$DB_ADMIN_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_ADMIN_USER -c "GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_APP_USER;"

# スキーマ作成
echo "テーブルを作成中..."
for sql_file in /opt/kyuuyomeisai/sql/*.sql; do
    echo "実行中: $sql_file"
    PGPASSWORD=$DB_APP_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_APP_USER -d $DB_NAME -f $sql_file
done

echo "データベース設定完了 ✓"

# 設定を保存
cat > /opt/kyuuyomeisai/.env <<EOF
DATABASE_URL=postgresql://$DB_APP_USER:$DB_APP_PASS@$DB_HOST:$DB_PORT/$DB_NAME
EOF
```

### 3.4 初期データ投入

```bash
#!/bin/bash

echo "初期データを投入中..."

# ロール定義
PGPASSWORD=$DB_APP_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_APP_USER -d $DB_NAME <<EOF
INSERT INTO roles (code, name, description) VALUES
('super_admin', 'スーパー管理者', '全社横断管理'),
('admin', '管理者', '会社内全権限'),
('accountant', '経理担当', '給与計算・帳票出力'),
('employee', '一般従業員', '自分の明細閲覧のみ')
ON CONFLICT (code) DO NOTHING;
EOF

# 所得税額表（サンプル - 実際は別途CSVから投入）
# 通勤手当非課税限度額（サンプル）
# その他マスタデータ

echo "初期データ投入完了 ✓"
```

### 3.5 設定ファイル生成

```bash
#!/bin/bash

echo "設定ファイルを生成中..."

# JWTシークレット生成
JWT_SECRET=$(openssl rand -hex 32)

# .envファイル作成
cat >> /opt/kyuuyomeisai/.env <<EOF
# Application
APP_NAME=kyuuyomeisai
APP_ENV=production
DEBUG=false

# Database
DATABASE_URL=postgresql://$DB_APP_USER:$DB_APP_PASS@$DB_HOST:$DB_PORT/$DB_NAME

# Security
JWT_SECRET=$JWT_SECRET
JWT_ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=30

# Redis
REDIS_URL=redis://localhost:6379/0

# File Storage
FILE_STORAGE_PATH=/var/kyuuyomeisai/files

# CORS
CORS_ORIGINS=https://yourdomain.com

# Email (optional)
# SMTP_HOST=smtp.example.com
# SMTP_PORT=587
# SMTP_USER=noreply@example.com
# SMTP_PASSWORD=password
EOF

chmod 600 /opt/kyuuyomeisai/.env

echo "設定ファイル生成完了 ✓"
```

### 3.6 Webサーバー設定（Nginx）

```bash
#!/bin/bash

echo "Nginxを設定中..."

# ドメイン名入力
read -p "ドメイン名（例: payroll.example.com）: " DOMAIN_NAME

# Nginx設定ファイル作成
cat > /etc/nginx/sites-available/kyuuyomeisai <<EOF
server {
    listen 80;
    server_name $DOMAIN_NAME;
    
    # HTTP to HTTPS redirect
    return 301 https://\$server_name\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name $DOMAIN_NAME;
    
    # SSL証明書（Let's Encryptなどで取得）
    # ssl_certificate /etc/letsencrypt/live/$DOMAIN_NAME/fullchain.pem;
    # ssl_certificate_key /etc/letsencrypt/live/$DOMAIN_NAME/privkey.pem;
    
    # フロントエンド（静的ファイル）
    location / {
        root /opt/kyuuyomeisai/frontend/build;
        try_files \$uri \$uri/ /index.html;
    }
    
    # バックエンドAPI
    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
    
    # ファイルアップロード上限
    client_max_body_size 50M;
}
EOF

# シンボリックリンク作成
ln -s /etc/nginx/sites-available/kyuuyomeisai /etc/nginx/sites-enabled/

# Nginx設定テスト
nginx -t

# Nginx再起動
systemctl restart nginx

echo "Nginx設定完了 ✓"
echo "注意: SSL証明書を設定してください（Let's Encrypt推奨）"
```

### 3.7 Systemdサービス登録

```bash
#!/bin/bash

echo "Systemdサービスを登録中..."

# Systemdサービスファイル作成
cat > /etc/systemd/system/kyuuyomeisai.service <<EOF
[Unit]
Description=Kyuuyomeisai Payroll System
After=network.target postgresql.service redis.service

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=/opt/kyuuyomeisai/backend
Environment="PATH=/opt/kyuuyomeisai/venv/bin"
EnvironmentFile=/opt/kyuuyomeisai/.env
ExecStart=/opt/kyuuyomeisai/venv/bin/uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

# サービス有効化・起動
systemctl daemon-reload
systemctl enable kyuuyomeisai
systemctl start kyuuyomeisai

echo "Systemdサービス登録完了 ✓"
echo "サービス状態: $(systemctl is-active kyuuyomeisai)"
```

---

## 4. 初回ログイン設定

### 4.1 初期管理者アカウント作成

```bash
#!/bin/bash

echo "初期管理者アカウントを作成中..."

# アカウント情報入力
read -p "管理者ユーザー名: " ADMIN_USERNAME
read -p "管理者メールアドレス: " ADMIN_EMAIL
read -sp "管理者パスワード: " ADMIN_PASSWORD
echo

# 会社ID（初回は1）
COMPANY_ID=1

# パスワードハッシュ生成（Pythonスクリプト）
HASHED_PASSWORD=$(python3 << EOF
from passlib.context import CryptContext
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
print(pwd_context.hash("$ADMIN_PASSWORD"))
EOF
)

# データベースに登録
PGPASSWORD=$DB_APP_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_APP_USER -d $DB_NAME <<EOF
-- 初期会社データ
INSERT INTO companies (company_id, name, closing_day, payment_day)
VALUES ($COMPANY_ID, '初期会社', 25, 10)
ON CONFLICT (company_id) DO NOTHING;

-- 管理者ユーザー
INSERT INTO users (company_id, username, email, password_hash, full_name, is_super_admin, is_active)
VALUES ($COMPANY_ID, '$ADMIN_USERNAME', '$ADMIN_EMAIL', '$HASHED_PASSWORD', '管理者', true, true);

-- ロール割当
INSERT INTO user_roles (company_id, user_id, role_id)
SELECT $COMPANY_ID, u.id, r.id
FROM users u, roles r
WHERE u.username = '$ADMIN_USERNAME' AND r.code = 'super_admin';
EOF

echo "初期管理者アカウント作成完了 ✓"
echo "ユーザー名: $ADMIN_USERNAME"
echo "メール: $ADMIN_EMAIL"
```

---

## 5. インストール完了メッセージ

```bash
#!/bin/bash

echo ""
echo "========================================="
echo "  インストール完了"
echo "========================================="
echo ""
echo "給与明細管理システム (kyuuyomeisai) のインストールが完了しました。"
echo ""
echo "アクセスURL: https://$DOMAIN_NAME"
echo "管理者ユーザー名: $ADMIN_USERNAME"
echo ""
echo "次のステップ:"
echo "1. SSL証明書を設定してください（Let's Encryptなど）"
echo "2. ブラウザでアクセスしてログインしてください"
echo "3. 会社マスタ・従業員マスタを登録してください"
echo "4. 料率テーブル・税額表を確認してください"
echo ""
echo "サービス管理コマンド:"
echo "  起動: systemctl start kyuuyomeisai"
echo "  停止: systemctl stop kyuuyomeisai"
echo "  再起動: systemctl restart kyuuyomeisai"
echo "  状態確認: systemctl status kyuuyomeisai"
echo ""
echo "ログ確認:"
echo "  journalctl -u kyuuyomeisai -f"
echo ""
echo "========================================="
```

---

## 6. アンインストール

```bash
#!/bin/bash

echo "アンインストール中..."

# サービス停止・削除
systemctl stop kyuuyomeisai
systemctl disable kyuuyomeisai
rm /etc/systemd/system/kyuuyomeisai.service
systemctl daemon-reload

# Nginx設定削除
rm /etc/nginx/sites-enabled/kyuuyomeisai
rm /etc/nginx/sites-available/kyuuyomeisai
systemctl restart nginx

# データベース削除（任意）
read -p "データベースも削除しますか？（y/n）: " DELETE_DB
if [ "$DELETE_DB" = "y" ]; then
    PGPASSWORD=$DB_ADMIN_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_ADMIN_USER -c "DROP DATABASE IF EXISTS $DB_NAME;"
    PGPASSWORD=$DB_ADMIN_PASS psql -h $DB_HOST -p $DB_PORT -U $DB_ADMIN_USER -c "DROP USER IF EXISTS $DB_APP_USER;"
fi

# ファイル削除
rm -rf /opt/kyuuyomeisai
rm -rf /var/kyuuyomeisai

echo "アンインストール完了"
```

---

## 7. トラブルシューティング

### 7.1 インストールエラー

| エラー | 原因 | 対処法 |
|-------|------|--------|
| PostgreSQL接続エラー | 接続情報誤り | ホスト・ポート・ユーザー名・パスワードを確認 |
| Permission denied | 権限不足 | sudo で実行 |
| Port already in use | ポート競合 | 他のサービスを停止 or ポート変更 |

### 7.2 ログ確認

```bash
# アプリケーションログ
journalctl -u kyuuyomeisai -f

# Nginxログ
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log

# PostgreSQLログ
tail -f /var/log/postgresql/postgresql-15-main.log
```

---

**文書終了**
