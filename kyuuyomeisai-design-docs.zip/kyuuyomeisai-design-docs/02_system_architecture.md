# システム構成図とアーキテクチャ設計

**文書バージョン**: v1.0  
**作成日**: 2026-02-09

---

## 1. システム全体構成

```mermaid
graph TB
    subgraph "クライアント層"
        Browser[Webブラウザ]
    end
    
    subgraph "Webサーバー層"
        Nginx[Nginx<br/>リバースプロキシ<br/>SSL終端]
    end
    
    subgraph "アプリケーション層"
        Frontend[React App<br/>Material UI<br/>静的ファイル配信]
        Backend[FastAPI<br/>Uvicorn<br/>ビジネスロジック]
    end
    
    subgraph "データ層"
        PostgreSQL[(PostgreSQL<br/>給与データ<br/>マスタデータ)]
        SMB[SMBサーバー<br/>PDF/画像ファイル]
        Redis[(Redis<br/>JWTブラックリスト<br/>セッション)]
    end
    
    subgraph "外部連携"
        ProjectMgmt[プロジェクト管理システム<br/>勤怠データ連携]
    end
    
    Browser -->|HTTPS| Nginx
    Nginx -->|静的ファイル| Frontend
    Nginx -->|API Proxy| Backend
    Backend -->|SQLAlchemy| PostgreSQL
    Backend -->|ファイルI/O| SMB
    Backend -->|JWT検証| Redis
    Backend -.->|将来連携| ProjectMgmt
    ProjectMgmt -.->|DB直接参照| PostgreSQL
```

---

## 2. アーキテクチャパターン

### 2.1 全体構成
- **アーキテクチャスタイル**: 3層アーキテクチャ + SPA
- **フロントエンド**: SPA（Single Page Application）
- **バックエンド**: RESTful API
- **データベース**: リレーショナルデータベース（PostgreSQL）

### 2.2 フロントエンドアーキテクチャ

```
src/
├── components/          # 再利用可能なUIコンポーネント
│   ├── common/         # 共通コンポーネント（Button, Input等）
│   ├── layout/         # レイアウトコンポーネント
│   └── features/       # 機能別コンポーネント
├── pages/              # ページコンポーネント（ルーティング単位）
├── hooks/              # カスタムフック
├── store/              # 状態管理（Redux/Zustand）
├── services/           # API通信層
├── utils/              # ユーティリティ関数
├── types/              # TypeScript型定義
└── routes/             # ルーティング定義
```

**設計原則**:
- コンポーネントの再利用性を重視
- 状態管理は最小限に（必要な箇所のみ）
- API通信は services 層に集約
- Material UIテーマのカスタマイズ

### 2.3 バックエンドアーキテクチャ

```
app/
├── main.py             # FastAPIアプリケーションエントリーポイント
├── api/                # APIエンドポイント
│   ├── v1/            # API v1
│   │   ├── auth.py    # 認証
│   │   ├── companies.py
│   │   ├── employees.py
│   │   ├── payrolls.py
│   │   └── ...
│   └── deps.py        # 依存性注入
├── core/              # コア機能
│   ├── config.py      # 設定管理
│   ├── security.py    # セキュリティ（JWT等）
│   └── database.py    # DB接続
├── models/            # SQLAlchemyモデル
├── schemas/           # Pydanticスキーマ（入出力）
├── services/          # ビジネスロジック層
│   ├── payroll_calculator.py
│   ├── tax_calculator.py
│   └── ...
├── repositories/      # データアクセス層
└── utils/             # ユーティリティ
```

**設計原則**:
- レイヤードアーキテクチャ（API → Service → Repository → Model）
- 依存性注入（FastAPI Depends）
- ビジネスロジックとデータアクセスの分離
- Pydanticによる入出力バリデーション

---

## 3. データフロー

### 3.1 給与計算フロー

```mermaid
sequenceDiagram
    participant User as 管理者
    participant Frontend as React App
    participant API as FastAPI
    participant Calculator as 給与計算エンジン
    participant DB as PostgreSQL
    
    User->>Frontend: 給与計算実行
    Frontend->>API: POST /api/v1/payrolls/calculate
    API->>DB: 勤怠データ取得
    DB-->>API: 勤怠データ
    API->>DB: 従業員情報取得
    DB-->>API: 従業員情報
    API->>DB: 料率テーブル取得
    DB-->>API: 料率データ
    API->>Calculator: 給与計算実行
    Calculator-->>API: 計算結果
    API->>DB: 計算結果保存
    DB-->>API: 保存完了
    API-->>Frontend: 計算結果
    Frontend-->>User: 結果表示
```

### 3.2 認証フロー

```mermaid
sequenceDiagram
    participant User as ユーザー
    participant Frontend as React App
    participant API as FastAPI
    participant Redis as Redis
    participant DB as PostgreSQL
    
    User->>Frontend: ログイン（ID/PW）
    Frontend->>API: POST /api/v1/auth/login
    API->>DB: ユーザー認証
    DB-->>API: ユーザー情報
    API->>API: JWTトークン生成
    API->>Redis: リフレッシュトークン保存
    API-->>Frontend: アクセストークン<br/>(httpOnly Cookie)
    Frontend-->>User: ダッシュボード表示
    
    Note over User,DB: 以降のリクエスト
    User->>Frontend: 操作
    Frontend->>API: API呼び出し<br/>(Cookie自動送信)
    API->>API: JWT検証
    API->>Redis: ブラックリスト確認
    Redis-->>API: 有効
    API->>DB: データ操作
    DB-->>API: 結果
    API-->>Frontend: レスポンス
```

---

## 4. セキュリティアーキテクチャ

### 4.1 認証・認可フロー

```mermaid
graph LR
    A[クライアント] -->|1. ログイン要求| B[FastAPI]
    B -->|2. 認証| C[PostgreSQL]
    C -->|3. ユーザー情報| B
    B -->|4. JWT生成| B
    B -->|5. Cookie設定| A
    A -->|6. API呼び出し<br/>Cookie自動送信| B
    B -->|7. JWT検証| D[Redis<br/>ブラックリスト]
    D -->|8. 有効確認| B
    B -->|9. RLS適用| C
    C -->|10. フィルタ済みデータ| B
    B -->|11. レスポンス| A
```

### 4.2 PostgreSQL RLS（Row Level Security）

**設定方針**:
```sql
-- 全テーブルでRLSを有効化
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees FORCE ROW LEVEL SECURITY;

-- 一般ユーザー用ポリシー（自社データのみ）
CREATE POLICY employees_tenant_isolation ON employees
    FOR ALL
    TO app_user
    USING (company_id = current_setting('app.current_company_id')::bigint);

-- スーパー管理者用ポリシー（全データ）
CREATE POLICY employees_super_admin ON employees
    FOR ALL
    TO app_user
    USING (app_is_super_admin());
```

**運用フロー**:
1. FastAPIがユーザー認証
2. セッション変数 `app.current_company_id` を設定
3. PostgreSQLが自動的にデータフィルタリング
4. アプリ側でも二重チェック

### 4.3 データ暗号化

| データ種別 | 暗号化方式 | 保存場所 |
|-----------|----------|---------|
| パスワード | bcrypt（ハッシュ化） | PostgreSQL |
| JWTシークレット | 環境変数 | サーバー |
| 銀行口座番号 | AES-256 | PostgreSQL |
| マイナンバー | AES-256 | PostgreSQL |
| PDFファイル | なし（アクセス制御） | SMBサーバー |
| 証明書画像 | なし（アクセス制御） | SMBサーバー |

---

## 5. デプロイメント構成

### 5.1 本番環境構成

```mermaid
graph TB
    subgraph "オンプレミスサーバー"
        subgraph "Webサーバー"
            Nginx[Nginx:443<br/>SSL/TLS]
        end
        
        subgraph "アプリケーションサーバー"
            Uvicorn1[Uvicorn:8001]
            Uvicorn2[Uvicorn:8002]
            Uvicorn3[Uvicorn:8003]
        end
        
        subgraph "データベースサーバー（既設）"
            PG[(PostgreSQL:5432)]
        end
        
        subgraph "キャッシュサーバー"
            Redis[(Redis:6379)]
        end
        
        subgraph "ファイルサーバー（既設）"
            SMB[SMBサーバー]
        end
    end
    
    Internet[インターネット] -->|HTTPS| Nginx
    Nginx -->|ロードバランシング| Uvicorn1
    Nginx --> Uvicorn2
    Nginx --> Uvicorn3
    Uvicorn1 --> PG
    Uvicorn1 --> Redis
    Uvicorn1 --> SMB
    Uvicorn2 --> PG
    Uvicorn2 --> Redis
    Uvicorn2 --> SMB
    Uvicorn3 --> PG
    Uvicorn3 --> Redis
    Uvicorn3 --> SMB
```

### 5.2 サーバースペック推奨

#### Webサーバー（Nginx）
- CPU: 2コア以上
- メモリ: 2GB以上
- ディスク: 20GB以上

#### アプリケーションサーバー（FastAPI）
- CPU: 4コア以上
- メモリ: 8GB以上
- ディスク: 50GB以上

#### データベースサーバー（既設）
- CPU: 4コア以上
- メモリ: 16GB以上
- ディスク: 500GB以上（SSD推奨）

#### Redisサーバー
- CPU: 2コア
- メモリ: 4GB
- ディスク: 10GB

---

## 6. スケーラビリティ設計

### 6.1 水平スケーリング
- **FastAPI**: 複数プロセス起動（Uvicorn workers）
- **Nginx**: ロードバランシング
- **PostgreSQL**: リードレプリカ（将来的に検討）

### 6.2 垂直スケーリング
- サーバースペックの増強
- データベースチューニング
- インデックス最適化

### 6.3 キャッシュ戦略
- **Redis**: JWTブラックリスト、セッション
- **アプリレベル**: 料率テーブル、税額表（頻繁に参照）
- **ブラウザキャッシュ**: 静的ファイル（React App）

---

## 7. 監視・ログ

### 7.1 ログ種別
| ログ種別 | 出力先 | 保持期間 |
|---------|-------|---------|
| アクセスログ | /var/log/nginx/ | 90日 |
| アプリケーションログ | /var/log/kyuuyomeisai/ | 90日 |
| エラーログ | /var/log/kyuuyomeisai/ | 1年 |
| 監査ログ | PostgreSQL | 7年 |

### 7.2 監視項目
- サーバーリソース（CPU、メモリ、ディスク）
- アプリケーション応答時間
- データベース接続数
- エラー発生率

---

## 8. バックアップ戦略

### 8.1 DR用バックアップ（全データベース）
- **方式**: pg_dump
- **頻度**: 毎日深夜2時
- **保存先**: 外部ストレージ
- **世代管理**: 7世代（1週間分）

### 8.2 会社別エクスポート
- **方式**: アプリ経由でデータ抽出
- **頻度**: 手動実行 or 週次定期
- **出力形式**: ZIP + パスワード暗号化
- **保存先**: 管理者指定

---

## 9. ディザスタリカバリ

### 9.1 RPO/RTO目標
- **RPO（Recovery Point Objective）**: 24時間以内
- **RTO（Recovery Time Objective）**: 4時間以内

### 9.2 リストア手順
1. データベースサーバーの復旧
2. 最新バックアップからリストア（pg_restore）
3. アプリケーションサーバーの起動
4. 動作確認
5. サービス再開

---

**文書終了**
