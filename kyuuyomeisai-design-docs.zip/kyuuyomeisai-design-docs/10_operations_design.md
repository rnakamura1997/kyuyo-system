# 運用保守設計

**文書バージョン**: v1.0  
**作成日**: 2026-02-09

---

## 1. 運用保守概要

### 1.1 運用体制
- **システム管理者**: 中村様（NakamuraService）
- **運用担当**: 混合（会社によって異なる）
- **開発・保守**: 開発チーム

### 1.2 運用時間
- **稼働時間**: 24時間365日
- **メンテナンス時間**: 深夜帯（2:00-5:00）
- **目標稼働率**: 99%以上

---

## 2. バックアップ・リストア

### 2.1 DR用バックアップ（全データベース）

#### バックアップ方式
```bash
#!/bin/bash
# /opt/kyuuyomeisai/scripts/backup_full.sh

BACKUP_DIR="/var/backups/kyuuyomeisai"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="kyuuyomeisai_full_$TIMESTAMP.sql.gz"

# PostgreSQLダンプ
pg_dump -h localhost -U kyuuyomeisai_app kyuuyomeisai | gzip > "$BACKUP_DIR/$BACKUP_FILE"

# 古いバックアップ削除（7世代保持）
find $BACKUP_DIR -name "kyuuyomeisai_full_*.sql.gz" -mtime +7 -delete

# 外部ストレージへ転送
rsync -avz $BACKUP_DIR/$BACKUP_FILE backup-server:/backups/kyuuyomeisai/
```

#### スケジュール
```bash
# crontab設定
0 2 * * * /opt/kyuuyomeisai/scripts/backup_full.sh
```

#### リストア手順
```bash
#!/bin/bash
# リストア

# データベース削除・再作成
dropdb kyuuyomeisai
createdb kyuuyomeisai

# リストア実行
gunzip -c /var/backups/kyuuyomeisai/kyuuyomeisai_full_20260209_020000.sql.gz | \
  psql -h localhost -U kyuuyomeisai_app kyuuyomeisai

# 動作確認
systemctl restart kyuuyomeisai
```

### 2.2 会社別エクスポート

#### 実装（管理画面から実行）
```python
import zipfile
from io import BytesIO

async def export_company_data(company_id: int):
    """会社データをエクスポート"""
    
    # データ取得
    employees = await get_employees(company_id)
    payroll_records = await get_payroll_records(company_id)
    
    # ZIPファイル作成
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # 従業員データ
        zip_file.writestr('employees.csv', employees_to_csv(employees))
        
        # 給与データ
        zip_file.writestr('payroll_records.csv', payroll_to_csv(payroll_records))
        
        # PDFファイル
        for record in payroll_records:
            if record.pdf_path:
                zip_file.write(record.pdf_path, f'pdfs/{record.id}.pdf')
    
    # パスワード暗号化（pyminizip）
    password = generate_password()
    encrypted_zip = encrypt_zip(zip_buffer.getvalue(), password)
    
    return encrypted_zip, password
```

### 2.3 データ保持期間管理

#### 自動削除スクリプト
```python
from datetime import datetime, timedelta

async def cleanup_old_data():
    """7年以上前のデータを論理削除"""
    cutoff_date = datetime.now() - timedelta(days=7*365)
    
    # 給与データ
    await db.execute(
        update(PayrollRecord)
        .where(PayrollRecord.payment_date < cutoff_date)
        .values(is_deleted=True)
    )
    
    # 監査ログは削除しない（永続保持）
```

---

## 3. 監視

### 3.1 監視項目

| 項目 | 監視方法 | 閾値 | アクション |
|------|---------|------|-----------|
| サーバーCPU | top/htop | 80%以上 | アラート |
| メモリ使用率 | free | 90%以上 | アラート |
| ディスク使用率 | df | 85%以上 | アラート |
| アプリ応答時間 | ログ分析 | 3秒以上 | アラート |
| DB接続数 | pg_stat_activity | 80%以上 | アラート |
| エラー発生率 | ログ分析 | 1%以上 | アラート |
| サービス稼働 | systemctl | Down | 自動再起動 |

### 3.2 監視スクリプト例

```bash
#!/bin/bash
# /opt/kyuuyomeisai/scripts/health_check.sh

# アプリケーション稼働確認
if ! systemctl is-active --quiet kyuuyomeisai; then
    echo "ERROR: kyuuyomeisai is not running"
    systemctl restart kyuuyomeisai
    # メール通知
    echo "kyuuyomeisai was restarted" | mail -s "System Alert" admin@example.com
fi

# データベース接続確認
if ! pg_isready -h localhost -U kyuuyomeisai_app; then
    echo "ERROR: Database is not ready"
    # メール通知
fi

# ディスク容量確認
DISK_USAGE=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 85 ]; then
    echo "WARNING: Disk usage is ${DISK_USAGE}%"
    # メール通知
fi
```

#### cron設定
```bash
*/5 * * * * /opt/kyuuyomeisai/scripts/health_check.sh
```

---

## 4. ログ管理

### 4.1 ログ種別

| ログ種別 | 出力先 | ローテーション | 保持期間 |
|---------|-------|--------------|---------|
| アクセスログ | /var/log/nginx/access.log | 日次 | 90日 |
| エラーログ | /var/log/nginx/error.log | 日次 | 90日 |
| アプリログ | /var/log/kyuuyomeisai/app.log | 日次 | 90日 |
| 監査ログ | PostgreSQL | - | 7年 |

### 4.2 ログローテーション設定

```bash
# /etc/logrotate.d/kyuuyomeisai

/var/log/kyuuyomeisai/*.log {
    daily
    rotate 90
    compress
    delaycompress
    notifempty
    create 0640 www-data www-data
    sharedscripts
    postrotate
        systemctl reload kyuuyomeisai
    endscript
}
```

### 4.3 ログ分析

```bash
#!/bin/bash
# エラーログ集計

echo "=== エラー件数（過去24時間） ==="
grep -i error /var/log/kyuuyomeisai/app.log | wc -l

echo "=== 上位エラー ==="
grep -i error /var/log/kyuuyomeisai/app.log | \
  awk '{print $5}' | sort | uniq -c | sort -rn | head -10
```

---

## 5. 定期メンテナンス

### 5.1 日次メンテナンス
- [ ] バックアップ実行確認
- [ ] ログ確認（エラー有無）
- [ ] ディスク容量確認

### 5.2 週次メンテナンス
- [ ] アプリケーションログ確認
- [ ] データベース統計情報更新
- [ ] 不要な一時ファイル削除

### 5.3 月次メンテナンス
- [ ] OSセキュリティアップデート
- [ ] データベース最適化（VACUUM）
- [ ] バックアップリストアテスト
- [ ] パフォーマンスレビュー

### 5.4 年次メンテナンス
- [ ] セキュリティ診断
- [ ] システム全体レビュー
- [ ] ハードウェア点検
- [ ] 料率テーブル更新（税制改正対応）

---

## 6. データベースメンテナンス

### 6.1 VACUUM実行

```bash
#!/bin/bash
# /opt/kyuuyomeisai/scripts/db_vacuum.sh

psql -h localhost -U kyuuyomeisai_app -d kyuuyomeisai -c "VACUUM ANALYZE;"
```

### 6.2 インデックス再構築

```bash
psql -h localhost -U kyuuyomeisai_app -d kyuuyomeisai -c "REINDEX DATABASE kyuuyomeisai;"
```

### 6.3 統計情報更新

```bash
psql -h localhost -U kyuuyomeisai_app -d kyuuyomeisai -c "ANALYZE;"
```

---

## 7. 料率テーブル更新

### 7.1 年度更新フロー

#### 1. 所得税額表更新
```sql
-- 新年度の税額表を追加
INSERT INTO income_tax_tables (table_type, valid_from, valid_to, income_from, income_to, dependents_count, tax_amount)
VALUES
('monthly_kou', '2026-01-01', NULL, 88000, 89000, 0, 520),
-- ... (国税庁公表データ)
```

#### 2. 社会保険料率更新
```sql
-- 前年度の有効期限を設定
UPDATE insurance_rates
SET valid_to = '2026-03-31'
WHERE insurance_type = 'health' AND valid_to IS NULL;

-- 新年度の料率を追加
INSERT INTO insurance_rates (insurance_type, valid_from, employee_rate, employer_rate, prefecture)
VALUES
('health', '2026-04-01', 0.0500, 0.0500, 'tokyo');
```

#### 3. 管理画面からの更新
- CSV一括インポート機能を提供
- 国税庁・協会けんぽのデータをそのまま取り込み可能

---

## 8. 障害対応

### 8.1 障害レベル

| レベル | 内容 | 対応時間 | 対応者 |
|-------|------|---------|--------|
| Critical | サービス停止 | 即時 | 管理者+開発 |
| High | 一部機能停止 | 4時間以内 | 管理者 |
| Medium | パフォーマンス低下 | 1営業日以内 | 管理者 |
| Low | 軽微な不具合 | 次回保守時 | 管理者 |

### 8.2 障害対応フロー

```mermaid
graph TD
    A[障害検知] --> B[初動対応]
    B --> C[影響範囲確認]
    C --> D{Critical?}
    D -->|Yes| E[サービス停止]
    D -->|No| F[部分停止]
    E --> G[原因調査]
    F --> G
    G --> H[復旧作業]
    H --> I[動作確認]
    I --> J{復旧完了?}
    J -->|No| G
    J -->|Yes| K[サービス再開]
    K --> L[事後報告書作成]
```

### 8.3 連絡体制

| 連絡先 | 役割 | 連絡方法 |
|-------|------|---------|
| 中村様 | システム管理者 | 電話/メール |
| 開発チーム | 技術サポート | Slack/メール |
| ユーザー | 障害通知 | システム通知/メール |

---

## 9. パフォーマンス最適化

### 9.1 データベースチューニング

#### スロークエリ検出
```sql
-- PostgreSQL設定
ALTER SYSTEM SET log_min_duration_statement = 1000;  -- 1秒以上
SELECT pg_reload_conf();

-- スロークエリ確認
SELECT query, calls, total_time, mean_time
FROM pg_stat_statements
ORDER BY total_time DESC
LIMIT 10;
```

#### インデックス追加
```sql
-- 使用頻度の高いクエリにインデックス追加
CREATE INDEX idx_payroll_records_status_payment 
ON payroll_records(company_id, status, payment_date DESC);
```

### 9.2 キャッシュ最適化

#### Redis設定
```python
import redis

redis_client = redis.Redis(host='localhost', port=6379, db=0)

# 料率テーブルをキャッシュ（1日有効）
def get_insurance_rates_cached(company_id: int):
    cache_key = f"insurance_rates:{company_id}"
    cached = redis_client.get(cache_key)
    
    if cached:
        return json.loads(cached)
    
    # DBから取得
    rates = get_insurance_rates_from_db(company_id)
    redis_client.setex(cache_key, 86400, json.dumps(rates))
    return rates
```

---

## 10. セキュリティパッチ適用

### 10.1 OS/ミドルウェア

```bash
# Ubuntu セキュリティアップデート
apt-get update
apt-get upgrade -y

# 再起動が必要か確認
if [ -f /var/run/reboot-required ]; then
    echo "再起動が必要です"
fi
```

### 10.2 Pythonパッケージ

```bash
# 脆弱性チェック
pip-audit

# アップデート
pip install --upgrade package_name
```

---

## 11. ドキュメント管理

### 11.1 保守ドキュメント
- [ ] システム構成図
- [ ] ネットワーク図
- [ ] データベース設計書
- [ ] 運用手順書
- [ ] 障害対応手順書
- [ ] バックアップ・リストア手順書

### 11.2 更新管理
- バージョン管理: Git
- 更新頻度: 変更時随時
- レビュー: 年1回

---

## 12. 問い合わせ対応

### 12.1 問い合わせ窓口
- **メール**: support@example.com
- **電話**: 03-XXXX-XXXX（平日9:00-18:00）
- **システム内**: お問い合わせフォーム

### 12.2 対応フロー
1. 問い合わせ受付
2. 内容確認・分類
3. 対応（即答 or 調査後回答）
4. フィードバック
5. FAQ更新

---

## 13. ユーザーサポート

### 13.1 マニュアル
- [ ] 管理者マニュアル
- [ ] 経理担当マニュアル
- [ ] 従業員マニュアル
- [ ] FAQ

### 13.2 トレーニング
- 初回導入時: システム説明会（2時間）
- 年次更新時: 新機能説明会（1時間）
- 随時: 個別サポート

---

**文書終了**
