# セキュリティ設計

**文書バージョン**: v1.0  
**作成日**: 2026-02-09

---

## 1. セキュリティ概要

### 1.1 セキュリティ方針
給与明細管理システムは機密性の高い個人情報を扱うため、以下の観点でセキュリティを強化する。

1. **認証・認可**: 正当なユーザーのみがアクセス可能
2. **データ保護**: 通信・保存データの暗号化
3. **監査**: 全操作の記録と追跡可能性
4. **脆弱性対策**: 一般的な攻撃手法への対策

---

## 2. 認証・認可

### 2.1 認証方式

#### JWT（JSON Web Token）
- **保存場所**: httpOnly Secure Cookie
- **有効期限**: アクセストークン30分、リフレッシュトークン30日
- **アルゴリズム**: HS256
- **ペイロード**:
  ```json
  {
    "user_id": 1,
    "username": "admin",
    "company_id": 1,
    "is_super_admin": false,
    "exp": 1640000000
  }
  ```

#### ブラックリスト方式
- ログアウト時にトークンをRedisブラックリストに登録
- トークン検証時にブラックリスト確認
- 有効期限まで保持

#### リフレッシュトークンローテーション
- リフレッシュトークン使用時に新しいトークンを発行
- 古いトークンは無効化
- トークン盗難のリスク軽減

### 2.2 パスワードポリシー

#### 要件
- 最小8文字
- 英大文字・小文字・数字を各1文字以上含む
- 特殊文字推奨
- 過去3回分のパスワードは再利用不可

#### ハッシュ化
- **アルゴリズム**: bcrypt
- **ソルトラウンド**: 12
- **実装例**:
  ```python
  from passlib.context import CryptContext
  pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
  hashed = pwd_context.hash(password)
  ```

### 2.3 ロールベースアクセス制御（RBAC）

#### ロール定義
| ロール | 権限 |
|-------|------|
| super_admin | 全社横断管理、システム設定 |
| admin | 会社内全権限 |
| accountant | 給与計算・帳票出力 |
| employee | 自分の明細閲覧のみ |

#### 権限チェック
- **API層**: FastAPIのdependencies
- **データベース層**: PostgreSQL RLS
- **フロントエンド層**: ルート保護HOC

**実装例（FastAPI）**:
```python
from fastapi import Depends, HTTPException

def require_role(required_roles: List[str]):
    def dependency(current_user: User = Depends(get_current_user)):
        if not any(role in current_user.roles for role in required_roles):
            raise HTTPException(status_code=403, detail="権限がありません")
        return current_user
    return dependency

@router.get("/employees")
def get_employees(
    current_user: User = Depends(require_role(["super_admin", "admin"]))
):
    # 処理
    pass
```

---

## 3. データ保護

### 3.1 通信の暗号化

#### SSL/TLS
- **プロトコル**: TLS 1.2以上
- **証明書**: Let's Encrypt推奨
- **HSTS**: 有効化
- **Nginx設定例**:
  ```nginx
  ssl_protocols TLSv1.2 TLSv1.3;
  ssl_ciphers HIGH:!aNULL:!MD5;
  add_header Strict-Transport-Security "max-age=31536000" always;
  ```

### 3.2 データの暗号化

#### 保存データ暗号化

| データ種別 | 暗号化方式 | 鍵管理 |
|-----------|----------|--------|
| パスワード | bcrypt（ハッシュ化） | - |
| 銀行口座番号 | AES-256-GCM | 環境変数 |
| マイナンバー | AES-256-GCM | 環境変数 |
| JWTシークレット | - | 環境変数 |

**実装例（Python Cryptography）**:
```python
from cryptography.fernet import Fernet

# 暗号化キー生成（初回のみ）
key = Fernet.generate_key()
cipher_suite = Fernet(key)

# 暗号化
encrypted_data = cipher_suite.encrypt(b"sensitive_data")

# 復号化
decrypted_data = cipher_suite.decrypt(encrypted_data)
```

### 3.3 PostgreSQL RLS

#### 実装
```sql
-- RLS有効化
ALTER TABLE employees ENABLE ROW LEVEL SECURITY;
ALTER TABLE employees FORCE ROW LEVEL SECURITY;

-- ポリシー作成
CREATE POLICY employees_tenant_isolation ON employees
    FOR ALL
    TO app_user
    USING (company_id = current_setting('app.current_company_id')::bigint)
    WITH CHECK (company_id = current_setting('app.current_company_id')::bigint);

-- スーパー管理者用
CREATE POLICY employees_super_admin ON employees
    FOR ALL
    TO app_user
    USING (current_setting('app.is_super_admin', true)::boolean = true);
```

#### セッション変数設定
```python
async def set_rls_context(db: AsyncSession, user: User):
    await db.execute(
        text("SET LOCAL app.current_company_id = :company_id"),
        {"company_id": user.company_id}
    )
    await db.execute(
        text("SET LOCAL app.is_super_admin = :is_super_admin"),
        {"is_super_admin": user.is_super_admin}
    )
```

---

## 4. 脆弱性対策

### 4.1 SQLインジェクション

#### 対策
- **ORM使用**: SQLAlchemy
- **プレースホルダー**: 必須
- **入力検証**: Pydantic

**NG例**:
```python
# 危険！
query = f"SELECT * FROM users WHERE username = '{username}'"
```

**OK例**:
```python
# 安全
query = select(User).where(User.username == username)
result = await db.execute(query)
```

### 4.2 XSS（クロスサイトスクリプティング）

#### 対策
- **エスケープ**: React自動エスケープ
- **dangerouslySetInnerHTML**: 使用禁止
- **CSP**: Content Security Policy設定

**Nginx設定**:
```nginx
add_header Content-Security-Policy "default-src 'self'; script-src 'self'";
```

### 4.3 CSRF（クロスサイトリクエストフォージェリ）

#### 対策
- **SameSite Cookie**: Strict
- **CSRF Token**: FastAPIのCSRFProtection
- **Origin/Refererチェック**

**FastAPI設定**:
```python
from fastapi_csrf_protect import CsrfProtect

app.add_middleware(
    CsrfProtect,
    cookie_name="csrf_token",
    cookie_samesite="strict"
)
```

### 4.4 XXE（XML外部エンティティ）

#### 対策
- **XML処理**: 外部エンティティ無効化
- **JSON優先**: XMLの使用を最小限に

### 4.5 SSRF（サーバーサイドリクエストフォージェリ）

#### 対策
- **URL検証**: ホワイトリスト方式
- **内部IPアクセス禁止**: プライベートIP拒否
- **リダイレクト制限**: 外部URLへのリダイレクト制限

### 4.6 ファイルアップロード

#### 対策
- **拡張子検証**: ホワイトリスト（.pdf, .jpg, .png）
- **ファイルサイズ制限**: 50MB
- **MIMEタイプチェック**: python-magic
- **ファイル名サニタイズ**: UUID使用
- **実行権限付与禁止**

**実装例**:
```python
import magic
from uuid import uuid4

def save_uploaded_file(file: UploadFile):
    # MIMEタイプチェック
    mime = magic.from_buffer(file.file.read(1024), mime=True)
    allowed_types = ["application/pdf", "image/jpeg", "image/png"]
    if mime not in allowed_types:
        raise ValueError("許可されていないファイル形式です")
    
    # ファイル名をUUIDに置換
    ext = file.filename.split('.')[-1]
    new_filename = f"{uuid4()}.{ext}"
    
    # 保存
    save_path = f"/var/kyuuyomeisai/files/{new_filename}"
    with open(save_path, "wb") as f:
        f.write(file.file.read())
    
    return new_filename
```

---

## 5. 監査ログ

### 5.1 記録対象

| イベント | 記録内容 |
|---------|---------|
| ログイン | ユーザーID、IPアドレス、日時 |
| ログアウト | ユーザーID、日時 |
| データ作成 | テーブル名、レコードID、新値 |
| データ更新 | テーブル名、レコードID、旧値、新値 |
| データ削除 | テーブル名、レコードID、旧値 |
| 給与確定 | 給与明細ID、確定者、日時 |
| PDF閲覧 | 給与明細ID、閲覧者、日時 |

### 5.2 実装

```python
async def log_audit(
    db: AsyncSession,
    user_id: int,
    action: str,
    table_name: str = None,
    record_id: int = None,
    old_values: dict = None,
    new_values: dict = None,
    ip_address: str = None,
    user_agent: str = None
):
    audit_log = AuditLog(
        user_id=user_id,
        action=action,
        table_name=table_name,
        record_id=record_id,
        old_values=old_values,
        new_values=new_values,
        ip_address=ip_address,
        user_agent=user_agent,
        created_at=datetime.utcnow()
    )
    db.add(audit_log)
    await db.commit()
```

### 5.3 保持期間
- **監査ログ**: 7年間
- **削除禁止**: 物理削除不可

---

## 6. セッション管理

### 6.1 セッションタイムアウト
- **アイドルタイムアウト**: 30分
- **絶対タイムアウト**: 12時間

### 6.2 同時ログイン制御
- 同一ユーザーの複数セッション許可
- セッション一覧表示・強制ログアウト機能

---

## 7. レート制限

### 7.1 API レート制限

| エンドポイント | 制限 |
|--------------|------|
| /auth/login | 5回/分 |
| その他（認証なし） | 100回/時間 |
| その他（認証あり） | 1000回/時間 |

### 7.2 実装（FastAPI Limiter）

```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)

@app.post("/auth/login")
@limiter.limit("5/minute")
async def login(request: Request, ...):
    pass
```

---

## 8. セキュリティヘッダー

### 8.1 推奨ヘッダー

```nginx
add_header X-Frame-Options "DENY" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
add_header Content-Security-Policy "default-src 'self'" always;
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
```

---

## 9. バックアップセキュリティ

### 9.1 バックアップデータの保護
- **暗号化**: AES-256
- **アクセス制御**: 管理者のみ
- **保存場所**: 外部ストレージ（別拠点推奨）

### 9.2 会社別エクスポート
- **ZIP暗号化**: パスワード保護
- **パスワード通知**: 別経路（メール等）

---

## 10. 脆弱性診断

### 10.1 定期診断
- **頻度**: 年1回
- **範囲**: Webアプリケーション、インフラ
- **ツール**: OWASP ZAP、Burp Suite等

### 10.2 ペネトレーションテスト
- **頻度**: 年1回
- **実施者**: 外部セキュリティ専門家

---

## 11. インシデント対応

### 11.1 対応フロー
1. **検知**: 監視システム・ログ分析
2. **初動対応**: 被害拡大防止（サービス停止等）
3. **調査**: 原因特定・影響範囲確認
4. **復旧**: システム復旧・データリストア
5. **報告**: 関係者への報告・再発防止策

### 11.2 連絡体制
- システム管理者: 中村様
- 開発チーム: 緊急連絡先
- ユーザー: メール・システム通知

---

## 12. セキュリティチェックリスト

### リリース前チェック
- [ ] SSL/TLS証明書設定
- [ ] パスワードポリシー適用
- [ ] CORS設定
- [ ] CSP設定
- [ ] セキュリティヘッダー設定
- [ ] RLS有効化
- [ ] 監査ログ記録確認
- [ ] ファイルアップロード検証
- [ ] レート制限設定
- [ ] バックアップ暗号化
- [ ] 脆弱性診断実施

---

**文書終了**
